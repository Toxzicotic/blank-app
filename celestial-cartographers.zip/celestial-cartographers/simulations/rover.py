"""Rover and gravity-offload engineering estimates (blueprint Workspace 05).

IDEALISED. N = m*g and T = F*r alone do not reproduce rover-soil interaction. This module adds a
Bekker-style sinkage estimate and a slope energy model, and lists what it omits. Outputs are
estimates for test planning, not validated hardware predictions.
"""
from __future__ import annotations

import heapq
import math
from typing import Dict, List, Optional, Tuple

import numpy as np

# Bekker pressure-sinkage parameters, ILLUSTRATIVE ranges (kPa-based units). Replace with calibrated values.
SOILS = {
    "Lunar regolith simulant (illustrative)": {"kc": 1.4, "kphi": 820.0, "n": 1.0, "crr": 0.12},
    "Dry sand (illustrative)": {"kc": 0.99, "kphi": 1528.0, "n": 1.1, "crr": 0.15},
    "Compacted basaltic soil (illustrative)": {"kc": 5.0, "kphi": 2500.0, "n": 0.9, "crr": 0.06},
}

OMITTED = ["Wheel slip/skid dynamics", "Grouser/tread geometry", "Suspension kinematics and load transfer",
           "Soil cohesion/friction angle (full Mohr-Coulomb)", "Thermal and dust effects on drivetrain",
           "Inertial effects during acceleration"]


def gravity_offload(mass_kg: float, wheels: int, wheel_radius_m: float, wheel_width_m: float,
                    g_target: float, slope_deg: float, soil: str, g_earth: float = 9.81) -> Dict:
    th = math.radians(slope_deg)
    normal_earth = mass_kg * g_earth * math.cos(th)
    normal_target = mass_kg * g_target * math.cos(th)
    offload_force = normal_earth - normal_target                    # N the offload rig must remove
    offload_mass_equiv = offload_force / g_earth
    per_wheel_target = normal_target / wheels
    torque_target = (mass_kg * g_target * math.sin(th)) * wheel_radius_m / wheels  # T = F*r (grade resistance only)
    torque_earth = (mass_kg * g_earth * math.sin(th)) * wheel_radius_m / wheels
    s = SOILS[soil]
    z_t = bekker_sinkage(per_wheel_target, wheel_radius_m, wheel_width_m, s)
    z_e = bekker_sinkage(normal_earth / wheels, wheel_radius_m, wheel_width_m, s)
    return {"normal_load_earth_N": normal_earth, "normal_load_target_N": normal_target,
            "offload_force_N": offload_force, "offload_mass_equivalent_kg": offload_mass_equiv,
            "per_wheel_load_target_N": per_wheel_target, "torque_per_wheel_earth_Nm": torque_earth,
            "torque_per_wheel_target_Nm": torque_target, "sinkage_earth_mm": z_e * 1000,
            "sinkage_target_mm": z_t * 1000, "omitted": OMITTED}


def bekker_sinkage(load_n: float, r: float, b: float, soil: Dict) -> float:
    """Solve p = (kc/b + kphi) z^n with p = W / (b*l), l ~ 2*sqrt(2 r z) for a rigid wheel. Returns metres."""
    kc, kphi, n = soil["kc"], soil["kphi"], soil["n"]
    k = (kc / b + kphi) * 1000.0     # kPa-based parameters -> Pa-based
    z = 0.005
    for _ in range(200):
        l = max(2 * math.sqrt(max(2 * r * z - z * z, 1e-9)), 1e-3)
        p = load_n / (b * l)
        z_new = (p / k) ** (1.0 / n)
        z = 0.5 * z + 0.5 * min(z_new, r * 0.9)
    return z


# ---------------------------------------------------------------------------------------------
# Traverse planner: A* over a terrain cost surface, energy and line-of-sight estimates
# ---------------------------------------------------------------------------------------------
def astar(slope: np.ndarray, cell_m: float, start: Tuple[int, int], goal: Tuple[int, int], max_slope: float = 20.0):
    """8-connected A*. Cells steeper than max_slope are obstacles; cost grows with slope. Returns list of (row, col) or None."""
    n, m = slope.shape
    def h(a, b): return math.hypot(a[0] - b[0], a[1] - b[1]) * cell_m
    openq = [(h(start, goal), 0.0, start)]
    came: Dict[Tuple[int, int], Tuple[int, int]] = {}
    g = {start: 0.0}
    while openq:
        _, gc, cur = heapq.heappop(openq)
        if cur == goal:
            path = [cur]
            while cur in came:
                cur = came[cur]; path.append(cur)
            return path[::-1]
        if gc > g.get(cur, 1e18):
            continue
        for dr in (-1, 0, 1):
            for dc in (-1, 0, 1):
                if dr == 0 and dc == 0:
                    continue
                nb = (cur[0] + dr, cur[1] + dc)
                if not (0 <= nb[0] < n and 0 <= nb[1] < m):
                    continue
                s = slope[nb]
                if s > max_slope:
                    continue
                step = math.hypot(dr, dc) * cell_m * (1 + (s / max_slope) ** 2)
                ng = gc + step
                if ng < g.get(nb, 1e18):
                    g[nb] = ng; came[nb] = cur
                    heapq.heappush(openq, (ng + h(nb, goal), ng, nb))
    return None


def path_stats(h: np.ndarray, cell_m: float, path: List[Tuple[int, int]], mass_kg: float, g: float,
               crr: float, efficiency: float = 0.5) -> Dict:
    dist, gain, energy = 0.0, 0.0, 0.0
    for a, b in zip(path[:-1], path[1:]):
        d = math.hypot(a[0] - b[0], a[1] - b[1]) * cell_m
        dz = h[b] - h[a]
        dist += d
        if dz > 0:
            gain += dz
        th = math.atan2(dz, d)
        force = mass_kg * g * (crr * math.cos(th) + math.sin(th))
        energy += max(force, 0.0) * math.hypot(d, dz) / efficiency   # no regeneration assumed
    return {"distance_m": dist, "elevation_gain_m": gain, "energy_Wh": energy / 3600.0,
            "avg_energy_Wh_per_km": (energy / 3600.0) / (dist / 1000.0) if dist > 0 else 0.0}


def line_of_sight(h: np.ndarray, cell_m: float, tx: Tuple[int, int], rx: Tuple[int, int],
                  tx_height_m: float = 3.0, rx_height_m: float = 1.5) -> bool:
    """Geometric LOS between antenna heights above the DEM; ignores curvature and diffraction."""
    steps = int(max(abs(tx[0] - rx[0]), abs(tx[1] - rx[1])) * 2) + 2
    zt, zr = h[tx] + tx_height_m, h[rx] + rx_height_m
    for i in range(1, steps):
        t = i / steps
        r = tx[0] + (rx[0] - tx[0]) * t; c = tx[1] + (rx[1] - tx[1]) * t
        ground = h[int(round(r)), int(round(c))]
        if ground > zt + (zr - zt) * t:
            return False
    return True


def comms_coverage(h: np.ndarray, cell_m: float, path: List[Tuple[int, int]], lander: Tuple[int, int]) -> float:
    ok = sum(line_of_sight(h, cell_m, lander, p) for p in path)
    return ok / max(len(path), 1)
