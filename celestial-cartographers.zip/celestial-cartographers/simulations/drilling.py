"""Cryogenic drilling energy estimate (blueprint /api/simulation/drilling).

Specific-energy values are user-adjustable PLACEHOLDERS spanning broad ranges; they are not
calibrated for any real drill or material. Use for order-of-magnitude test planning only.
"""
import math
from typing import Dict

MEDIA = {  # specific energy MJ per m^3 of material removed (illustrative planning range)
    "Ice-cemented regolith": (40.0, 400.0),
    "Dry regolith": (10.0, 150.0),
    "Basaltic rock": (300.0, 1500.0),
}


def drilling_estimate(depth_m: float, diameter_m: float, rate_m_per_h: float, medium: str,
                      specific_energy_mj_m3: float, efficiency: float = 0.25) -> Dict:
    area = math.pi * (diameter_m / 2) ** 2
    volume = area * depth_m
    hours = depth_m / rate_m_per_h if rate_m_per_h > 0 else float("inf")
    energy_mj = volume * specific_energy_mj_m3 / max(efficiency, 1e-6)
    wh = energy_mj * 1e6 / 3600.0
    return {"volume_m3": volume, "duration_h": hours, "energy_Wh": wh,
            "mean_power_W": wh / hours if hours > 0 else float("nan"),
            "range_Wh": tuple(volume * s * 1e6 / 3600.0 / max(efficiency, 1e-6) for s in MEDIA[medium])}
