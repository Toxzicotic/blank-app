import pandas as pd
import plotly.graph_objects as go
import streamlit as st

from ai.clustering import cluster_environments
from components import three_views as tv
from components.charts import candidate_map, frost, heatmap, hbar, radar, score_bars
from components.context import sidebar
from components.theme import BLUE, FROST, ICE, hero, seed_banner
from config.mission_presets import DIMENSION_LABELS, DIMENSIONS, PRESETS
from data_sources.seed_catalog import TARGETS, get_targets
from scientific_engine.similarity import rank_candidates, sensitivity_analysis

ctx = sidebar()
t, rows, cands, obj, weights = ctx["target"], ctx["rows"], ctx["cands"], ctx["objective"], ctx["weights"]

hero("Analog Discovery Lab", "Rank Earth micro-sites against the target, expose uncertainty, run custom searches and compare both worlds.",
     eyebrow="Workspace 03", pills=["8D ranker", "sensitivity", "custom search", "atlas"])
seed_banner()

tabs = st.tabs(["Ranking", "Global atlas", "Sensitivity & uncertainty", "Custom search", "Dataset fusion", "Environment clusters", "Compare both worlds"])

# ---------------------------------------------------------------------------------------------
with tabs[0]:
    st.markdown(f"#### {obj} vs {t['name']}")
    df = pd.DataFrame([{"Rank": r["rank"], "Site": r["name"], "Status": cands[r["id"]]["status"], "Scale": cands[r["id"]]["scale"],
                        "Similarity": r["total"], "Coverage": r["coverage"], "Missing": ", ".join(DIMENSION_LABELS[d] for d in r["missing_dimensions"]) or "-",
                        **{DIMENSION_LABELS[d]: r["dimension_scores"][d] for d in DIMENSIONS}} for r in rows])
    st.dataframe(df, hide_index=True, column_config={
        "Similarity": st.column_config.ProgressColumn(min_value=0, max_value=1, format="%.2f"),
        "Coverage": st.column_config.ProgressColumn(min_value=0, max_value=1, format="percent"),
        **{DIMENSION_LABELS[d]: st.column_config.NumberColumn(format="%.2f") for d in DIMENSIONS}})
    st.caption("Empty cells are missing data, not zero. Dimension scores are shown beside the aggregate so no single number hides incomparable variables.")
    sel = st.multiselect("Sites to compare (radar and bars)", [r["name"] for r in rows], default=[r["name"] for r in rows[:3]], max_selections=4)
    chosen = [r for r in rows if r["name"] in sel]
    if chosen:
        a, b = st.columns(2)
        a.plotly_chart(radar(chosen), theme=None)
        b.plotly_chart(hbar(chosen), theme=None)
        st.plotly_chart(score_bars(chosen), theme=None)
        st.caption("Analogue fidelity, mission suitability and transferability are kept separate on purpose: a site can match geologically yet transfer poorly because gravity, pressure and radiation differ.")

# ---------------------------------------------------------------------------------------------
with tabs[1]:
    st.markdown("#### Interactive global analog atlas")
    f1, f2, f3 = st.columns(3)
    scales = sorted({c["scale"] for c in ctx["cand_list"]})
    sc = f1.multiselect("Scale", scales, default=scales)
    kind = f2.selectbox("Class", ["All", "Baseline / published", "Proposed (lesser-known)"])
    minsim = f3.slider("Minimum similarity", 0.0, 1.0, 0.0, 0.05)
    vals = {r["id"]: r["total"] for r in rows}
    sub = [c for c in ctx["cand_list"] if c["scale"] in sc and (vals[c["id"]] or 0) >= minsim
           and (kind == "All" or (kind.startswith("Baseline") and c["baseline"]) or (kind.startswith("Proposed") and not c["baseline"]))]
    if sub:
        st.plotly_chart(candidate_map(sub, vals), theme=None)
        tv.show(tv.globe_html("Earth", [{"name": c["name"], "lat": c["lat"], "lon": c["lon"], "value": vals[c["id"]],
                                          "line": f"{c['status']} · index {vals[c['id']]:.2f}", "selected": False} for c in sub], focus=(20, 40),
                              title="3D atlas"), 500)
        st.caption("Known baseline sites are labelled separately from lesser-characterised proposed candidates. Appearing here is not proof of a validated analogue.")
    else:
        st.info("No sites match the filters.")

# ---------------------------------------------------------------------------------------------
with tabs[2]:
    st.markdown("#### Does the ranking survive different weights?")
    sa = sensitivity_analysis(t, ctx["cand_list"], weights, obj)
    fig = go.Figure(go.Bar(y=[s["name"] for s in sa], x=[s["mean_rank"] for s in sa], orientation="h", marker=dict(color=ICE, line=dict(color=FROST, width=1)),
                           error_x=dict(type="data", array=[s["rank_std"] for s in sa], color=FROST),
                           text=[f"top-3 in {s['p_top3']:.0%}" for s in sa], textposition="outside"))
    fig.update_layout(title="Mean rank under 300 random weight perturbations (lower is better)", xaxis_title="mean rank ± std", yaxis=dict(autorange="reversed"))
    st.plotly_chart(frost(fig, 90 + 36 * len(sa), False), theme=None)
    st.dataframe(pd.DataFrame(sa).rename(columns={"name": "Site", "mean_rank": "Mean rank", "rank_std": "Std", "best_rank": "Best", "worst_rank": "Worst", "p_top3": "P(top 3)"}).drop(columns="id"),
                 hide_index=True, column_config={"P(top 3)": st.column_config.ProgressColumn(min_value=0, max_value=1, format="percent")})
    st.caption("Weights are drawn from a Dirichlet distribution centred on the active weights. 'P(top 3)' is a stability share across perturbations, not a probability of being the best analogue.")
    st.markdown("##### Why a site ranks differently under other objectives")
    pick = st.selectbox("Site", [r["name"] for r in rows], key="obj_site")
    cid = next(r["id"] for r in rows if r["name"] == pick)
    comp = []
    for o, w in PRESETS.items():
        rr = rank_candidates(t, ctx["cand_list"], w, o)
        me = next(x for x in rr if x["id"] == cid)
        comp.append({"Objective": o, "Rank": me["rank"], "Similarity": me["total"]})
    st.dataframe(pd.DataFrame(comp), hide_index=True, column_config={"Similarity": st.column_config.ProgressColumn(min_value=0, max_value=1, format="%.2f")})

# ---------------------------------------------------------------------------------------------
with tabs[3]:
    st.markdown("#### Custom analog search")
    st.caption("Define conditions and see which catalogue sites satisfy them. Unknown values never pass a filter silently; they are counted separately.")
    lithos = sorted({c["lithology"] for c in ctx["cand_list"]})
    minerals = sorted({m for c in ctx["cand_list"] for m in c["minerals"]})
    c1, c2, c3 = st.columns(3)
    lit = c1.multiselect("Lithology", lithos)
    mins = c1.multiselect("Must include minerals", minerals)
    slope = c2.slider("Slope (°)", 0, 40, (0, 40))
    temp = c2.slider("Mean temperature (°C)", -40, 50, (-40, 50))
    veg = c3.slider("Max vegetation / biology", 0.0, 1.0, 1.0, 0.05)
    wat = c3.slider("Min water/ice indicator", 0.0, 1.0, 0.0, 0.05)
    esc = st.multiselect("Exclude scales", sorted({c["scale"] for c in ctx["cand_list"]}))
    hits = []
    for c in ctx["cand_list"]:
        ok = (not lit or c["lithology"] in lit) and all(m in c["minerals"] for m in mins) and slope[0] <= c["slope_deg"] <= slope[1] \
             and temp[0] <= c["temp_mean_c"] <= temp[1] and c["biology"] <= veg and c["water_ice"] >= wat and c["scale"] not in esc
        if ok:
            hits.append({"Site": c["name"], "Lithology": c["lithology"], "Scale": c["scale"], "Slope": c["slope_deg"], "Mean T (°C)": c["temp_mean_c"],
                         "Biology": c["biology"], "Water/ice": c["water_ice"], "Data quality": c["data_quality"],
                         "Similarity": next(r["total"] for r in rows if r["id"] == c["id"])})
    st.markdown(f"**{len(hits)} of {len(ctx['cand_list'])} sites match.**")
    if hits:
        st.dataframe(pd.DataFrame(hits).sort_values("Similarity", ascending=False), hide_index=True,
                     column_config={"Similarity": st.column_config.ProgressColumn(min_value=0, max_value=1, format="%.2f")})

# ---------------------------------------------------------------------------------------------
with tabs[4]:
    st.markdown("#### Multi-dataset fusion profile")
    pick = st.selectbox("Candidate", [c["name"] for c in ctx["cand_list"]], key="fusion_site")
    c = next(x for x in ctx["cand_list"] if x["name"] == pick)
    fusion = [("DEM", "Elevation, topography", f"relief {c['relief_m']} m"), ("Slope products", "Terrain steepness", f"mean slope {c['slope_deg']}°"),
              ("Geological map", "Rock/mineral composition", f"{c['lithology']}; {', '.join(c['minerals'])}"),
              ("Thermal data", "Surface temperature", f"mean {c['temp_mean_c']} °C ({c['temp_min_c']} to {c['temp_max_c']})"),
              ("Vegetation", "Surface coverage", f"index {c['biology']}"), ("Water / ice datasets", "Water occurrence", f"{c['water_ice']} ({c['water_basis']})"),
              ("Aerosol / dust", "Surface processes", f"index {c['dust']}"), ("Cave surveys", "Subsurface evidence", f"index {c['caves']}")]
    st.dataframe(pd.DataFrame(fusion, columns=["Dataset category", "Contribution", "Derived value (seed)"]), hide_index=True)
    st.markdown("**Recorded sources:** " + "; ".join(c["sources"]))
    st.markdown("**Fusion checklist (must be done for real data):** harmonise CRS and vertical datum · convert units · align temporal windows · "
                "match spatial resolution with scale-aware aggregation · carry quality flags · preserve missing-data patterns · keep links to every contributing dataset and transformation.")
    st.caption(f"Nominal resolution {c['resolution_m']} m · data quality {c['data_quality']:.0%} · basis {c['basis']}.")

# ---------------------------------------------------------------------------------------------
with tabs[5]:
    st.markdown("#### Exploratory environment clusters")
    k = st.slider("Clusters", 2, 6, 4)
    cl = cluster_environments(ctx["cand_list"], k)
    fig = go.Figure()
    pal = [FROST, ICE, BLUE, "#ffffff", "#7f9ad6", "#b8dde8"]
    for i in sorted(cl["cluster"].unique()):
        s = cl[cl["cluster"] == i]
        fig.add_trace(go.Scatter(x=s["pc1"], y=s["pc2"], mode="markers+text", text=s["name"].str.split(" \\(").str[0], textposition="top center",
                                 marker=dict(size=16, color=pal[i % len(pal)], symbol=["circle", "diamond", "square", "triangle-up", "cross", "x"][i % 6],
                                             line=dict(color="#293681", width=1)), name=f"cluster {i + 1}"))
    fig.update_layout(title="k-means on catalogue feature vectors (PCA projection)", xaxis_title="PC 1", yaxis_title="PC 2")
    st.plotly_chart(frost(fig, 480), theme=None)
    st.caption("This groups feature vectors; it is not imagery classification. A cluster label is not a geological fact: validate against maps or expert review. "
               "CNN/U-Net terrain classification needs labelled imagery and is not part of this build.")

# ---------------------------------------------------------------------------------------------
with tabs[6]:
    st.markdown("#### Compare both worlds (kept independent)")
    st.caption("Each world is scored against its own targets with its own caveats; incompatible variables are not mixed.")
    cols = st.columns(2)
    for col, body in zip(cols, ["Moon", "Mars"]):
        with col:
            with st.container(key=f"glass_both_{body}"):
                tg = get_targets(body)
                pick = st.selectbox(f"{body} region", [x["id"] for x in tg], format_func=lambda i, tg=tg: next(x["name"] for x in tg if x["id"] == i), key=f"cmp_{body}")
                tt = next(x for x in tg if x["id"] == pick)
                rr = rank_candidates(tt, ctx["cand_list"], weights, obj)[:4]
                st.dataframe(pd.DataFrame([{"#": r["rank"], "Site": r["name"], "Similarity": r["total"], "Transferability*": r["transferability"]} for r in rr]),
                             hide_index=True, column_config={"Similarity": st.column_config.ProgressColumn(min_value=0, max_value=1, format="%.2f"),
                                                             "Transferability*": st.column_config.ProgressColumn(min_value=0, max_value=1, format="%.2f")})
                st.caption(f"{body}: gravity {1.62 if body == 'Moon' else 3.71} m/s², {'near-vacuum' if body == 'Moon' else 'thin CO₂ atmosphere (~0.6 kPa)'}. *Heuristic.")
