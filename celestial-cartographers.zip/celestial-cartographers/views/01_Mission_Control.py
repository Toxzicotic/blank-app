import pandas as pd
import plotly.graph_objects as go
import streamlit as st

from components.charts import frost
from components.context import _apply_preset, sidebar
from components.theme import FROST, ICE, hero, seed_banner
from config import scoring_config as cfg
from config.mission_presets import DIMENSION_LABELS, DIMENSIONS
from scientific_engine.explain import physical_scorecard
from scientific_engine.similarity import normalise_weights

ctx = sidebar()
t, rows, obj = ctx["target"], ctx["rows"], ctx["objective"]

hero("Mission Control", "Select a planetary target and objective, tune the dimension weights, and review analysis status.",
     eyebrow="Workspace 01", pills=[t["body"], obj, f"model {cfg.MODEL_VERSION}"])
seed_banner()

short = [r for r in rows if r["total"] is not None and r["total"] >= cfg.MEDIUM]
m = st.columns(4)
m[0].metric("Candidates screened", len(rows))
m[1].metric("Shortlisted (index ≥ 0.50)", len(short))
m[2].metric("Highest-ranked", rows[0]["name"].split(" (")[0], f"{rows[0]['total']:.2f}")
m[3].metric("Mean data coverage", f"{sum(r['coverage'] for r in rows) / len(rows):.0%}")

a, b = st.columns([1, 1.2])
with a:
    with st.container(key="glass_target"):
        st.markdown("#### Planetary target")
        st.markdown(f"**{t['name']}**")
        st.markdown(f"<span class='pill'>{t['body']}</span><span class='pill'>{t['scale']}</span><span class='pill ice'>{t['lithology']}</span>",
                    unsafe_allow_html=True)
        st.write(f"Coordinates: {t['lat']}°, {t['lon']}°  ·  nominal resolution {t['resolution_m']} m  ·  data quality {t['data_quality']:.0%}")
        st.write("Sources: " + "; ".join(t["sources"]))
        st.caption("Coordinates are planetocentric lat/lon in the body's own reference frame, not EPSG:4326. "
                   "Verify each dataset's CRS and datum before combining layers.")

with b:
    with st.container(key="glass_weights"):
        st.markdown("#### Dimension weights")
        st.caption("Placeholders drawn from the blueprint presets; edit freely. Weights are renormalised to sum to 100%.")
        cols = st.columns(2)
        for i, d in enumerate(DIMENSIONS):
            cols[i % 2].slider(DIMENSION_LABELS[d], 0, 100, key=f"w_{d}", format="%d%%")
        raw = sum(st.session_state[f"w_{d}"] for d in DIMENSIONS)
        st.caption(f"Raw total {raw}% → normalised to 100% for scoring.")
        st.button("Reset to preset", on_click=_apply_preset)

st.markdown("#### Ranking overview")
df = pd.DataFrame([{"Rank": r["rank"], "Site": r["name"], "Similarity": r["total"], "Fidelity": r["fidelity"],
                    "Suitability": r["suitability"], "Transferability*": r["transferability"], "Coverage": r["coverage"],
                    "Band": r["label"]} for r in rows[:8]])
st.dataframe(df, hide_index=True, column_config={
    **{k: st.column_config.ProgressColumn(k, min_value=0, max_value=1, format="%.2f") for k in ["Similarity", "Fidelity", "Suitability", "Transferability*"]},
    "Coverage": st.column_config.ProgressColumn("Coverage", min_value=0, max_value=1, format="percent")})
st.caption("Similarity = weighted index over available dimensions. Fidelity = environmental dimensions only. Suitability = access and terrain safety. "
           "*Transferability is a heuristic discount for unavoidable physical mismatches. None of these is a probability.")

c1, c2 = st.columns(2)
with c1:
    vals = [r["total"] for r in rows if r["total"] is not None]
    fig = go.Figure(go.Histogram(x=vals, nbinsx=10, marker=dict(color=ICE, line=dict(color=FROST, width=1)), opacity=.85))
    fig.update_layout(title="Similarity distribution", xaxis_title="similarity index", yaxis_title="candidates", xaxis=dict(range=[0, 1]))
    st.plotly_chart(frost(fig, 330, False), theme=None)
with c2:
    sc = physical_scorecard(t["body"])
    with st.container(key="glass_limits"):
        st.markdown("#### Major limitations (always visible)")
        for r in sc:
            if r["Earth site can..."] == "cannot reproduce":
                st.markdown(f"- **{r['Factor']}** · Earth {r['Earth']} vs {t['body']} {r['Target body']}")
        st.caption("These differences stay visible regardless of how high a similarity index is.")

st.markdown("#### Dataset coverage and confidence")
conf = pd.DataFrame([{"Site": r["name"], "Data quality": ctx["cands"][r["id"]].get("data_quality"), "Coverage of weighted dims": r["coverage"],
                      "Resolution (m)": ctx["cands"][r["id"]].get("resolution_m"), "Basis": ctx["cands"][r["id"]].get("basis")} for r in rows])
st.dataframe(conf, hide_index=True, column_config={
    "Data quality": st.column_config.ProgressColumn(min_value=0, max_value=1, format="%.2f"),
    "Coverage of weighted dims": st.column_config.ProgressColumn(min_value=0, max_value=1, format="percent")})
st.caption(f"Data version {cfg.DATA_VERSION} · model {cfg.MODEL_VERSION}. 'seed_estimate' means a hand-compiled demonstration value, not a pipeline measurement.")
