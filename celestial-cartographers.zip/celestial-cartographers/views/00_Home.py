import streamlit as st

from components import three_views as tv
from components.context import sidebar
from components.theme import hero, seed_banner
from data_sources.seed_catalog import CANDIDATES, TARGETS

ctx = sidebar()
t, rows = ctx["target"], ctx["rows"]

hero("Mapping Earth.<br>Understanding Other Worlds.",
     "A planetary-analogue discovery and mission-planning platform: find overlooked terrestrial micro-sites, compare them with lunar or "
     "Martian targets using measurable features, and see exactly where the analogy breaks down.",
     eyebrow="NASA Space Apps Challenge 2026",
     pills=["8-dimension similarity", "Explainable scores", "3D globe & terrain", "Live Earth conditions", "Field campaign briefs"])
seed_banner()

c1, c2, c3, c4 = st.columns(4)
c1.metric("Planetary targets", len(TARGETS))
c2.metric("Earth candidates", len(CANDIDATES))
top = rows[0]
c3.metric("Top match now", top["name"].split(" (")[0], f"index {top['total']:.2f}")
c4.metric("Objective", t["body"], ctx["objective"])

left, right = st.columns([1.35, 1])
with left:
    st.markdown("#### Earth analogue candidates")
    by = {r["id"]: r["total"] for r in rows}
    markers = [{"name": c["name"], "lat": c["lat"], "lon": c["lon"], "value": by.get(c["id"]),
                "line": f"{c['status']} · index {by[c['id']]:.2f}" if by.get(c["id"]) is not None else c["status"],
                "selected": c["id"] == top["id"]} for c in CANDIDATES]
    tv.show(tv.globe_html("Earth", markers, focus=(20, 40), title="Earth · candidate analogues"), 520)
with right:
    st.markdown(f"#### Target: {t['body']}")
    tmarks = [{"name": x["name"], "lat": x["lat"], "lon": x["lon"], "value": 1.0 if x["id"] == t["id"] else 0.3,
               "line": x["lithology"] + " · " + x["scale"], "selected": x["id"] == t["id"], "isTarget": x["id"] == t["id"]}
              for x in TARGETS if x["body"] == t["body"]]
    tv.show(tv.globe_html(t["body"], tmarks, focus=(t["lat"], t["lon"]), title=f"{t['body']} · {t['name'].split(' (')[0]}"), 520)

st.markdown("#### How the workflow runs")
cols = st.columns(5)
steps = [("1 · Choose", "Pick the Moon or Mars, a region and a mission objective."),
         ("2 · Explore", "Inspect the target's environmental fingerprint and 3D terrain."),
         ("3 · Discover", "Rank Earth sites across eight dimensions with uncertainty."),
         ("4 · Compare", "See what Earth reproduces, partially reproduces, or cannot."),
         ("5 · Plan", "Estimate loads, routes and drilling, then export a cited brief.")]
for col, (h, p) in zip(cols, steps):
    with col:
        with st.container(key=f"glass_step_{h[0]}"):
            st.markdown(f"**{h}**")
            st.caption(p)

st.markdown("<div class='tiny' style='margin-top:1rem'>Research prototype - not a certified mission-design system. "
            "Earth cannot reproduce extraterrestrial gravity, vacuum, radiation or atmospheric conditions.</div>", unsafe_allow_html=True)
