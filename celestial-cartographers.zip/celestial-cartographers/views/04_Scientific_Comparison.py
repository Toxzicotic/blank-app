import numpy as np
import pandas as pd
import plotly.graph_objects as go
import streamlit as st

from components.charts import frost, heatmap, terrain_profiles
from components.context import live_current, live_monthly, sidebar
from components.theme import BLUE, FROST, ICE, hero, seed_banner
from config.mission_presets import DIMENSION_LABELS, DIMENSIONS
from config.planetary_constants import PLANETS
from scientific_engine import dem, spectral
from scientific_engine.explain import compare_conditions, physical_scorecard, processes_for
from scientific_engine.seasonal import estimate_monthly, suitability_window

ctx = sidebar()
t, rows, cands, obj = ctx["target"], ctx["rows"], ctx["cands"], ctx["objective"]

hero("Scientific Comparison", "Where does the Earth analogue work, and where does it break down? Compare conditions, terrain, spectra, seasons and processes.",
     eyebrow="Workspace 04", pills=["scorecard", "live vs reference", "spectra", "seasonal calendar"])
seed_banner()

names = [r["name"] for r in rows]
pick = st.selectbox("Earth candidate", names, key="cmp_site")
cid = next(r["id"] for r in rows if r["name"] == pick)
c, res = cands[cid], next(r for r in rows if r["id"] == cid)

tabs = st.tabs(["Conditions & limitations", "Live vs reference", "Terrain cross-section", "Spectral matcher", "Seasonal calendar",
                "Heatmap", "Processes", "Resource indicators"])
ICON = {"match": "✓ match", "partial": "~ partial", "mismatch": "✕ mismatch", "unknown": "? unknown"}

with tabs[0]:
    st.markdown(f"#### {c['name']} vs {t['name']}")
    cr = pd.DataFrame(compare_conditions(t, c))
    cr["Status"] = cr["Status"].map(ICON)
    cr["Earth site"] = cr["Earth site"].astype(object).where(cr["Earth site"].notna(), "n/a")
    cr["Target"] = cr["Target"].astype(object).where(cr["Target"].notna(), "n/a")
    a, b = st.columns([1.1, 1])
    with a:
        st.markdown("##### Parameter comparison (target vs Earth site)")
        st.dataframe(cr, hide_index=True)
        st.caption("Tolerances for match/partial are simple placeholder bands. Unknown means no data, not a mismatch.")
    with b:
        st.markdown("##### Where it works vs where it breaks down")
        sc = pd.DataFrame(physical_scorecard(t["body"]))
        sc["Earth site can..."] = sc["Earth site can..."].map(lambda s: "~ partially (equipment)" if s == "partial" else "✕ cannot reproduce")
        st.dataframe(sc[["Factor", "Earth", "Target body", "Earth site can..."]], hide_index=True)
        st.caption("Fixed physical differences are never folded into the similarity score.")

with tabs[1]:
    st.markdown("#### Live Earth site vs planetary reference")
    cur = live_current(c["lat"], c["lon"])
    ref = PLANETS[t["body"]]
    if cur["ok"]:
        st.markdown(f"<span class='pill ice'>● LIVE</span><span class='tiny'>observed {cur['observed_time']} UTC · {cur['source']}</span>", unsafe_allow_html=True)
        rows_l = [
            {"Quantity": "Temperature (°C)", "Earth site (live)": round(cur["temperature_c"], 1), f"{t['body']} reference": f"{ref['temp_min_c']} to {ref['temp_max_c']}",
             "Status": "✓ within range" if ref["temp_min_c"] <= cur["temperature_c"] <= ref["temp_max_c"] else "✕ outside range"},
            {"Quantity": "Pressure (kPa)", "Earth site (live)": round(cur["pressure_kpa"], 2), f"{t['body']} reference": f"{ref['pressure_kpa']:.3g}",
             "Status": "✕ not reproducible" if cur["pressure_kpa"] > 10 * ref["pressure_kpa"] else "~ close"},
            {"Quantity": "Gravity (m/s²)", "Earth site (live)": 9.81, f"{t['body']} reference": ref["gravity"], "Status": "✕ not reproducible"},
        ]
        st.dataframe(pd.DataFrame(rows_l), hide_index=True)
        m = st.columns(4)
        m[0].metric("Cloud cover", f"{cur['cloud_pct']}%"); m[1].metric("Wind", f"{cur['wind_ms']:.1f} m/s")
        m[2].metric("Humidity", f"{cur['humidity_pct']}%"); m[3].metric("Solar", f"{cur['solar_wm2']:.0f} W/m²")
    else:
        st.warning(f"Live feed unavailable ({cur.get('error', '')}). Reference values still apply; reconnect to see live data.")
        st.dataframe(pd.DataFrame([{"Quantity": "Temperature (°C)", "Earth site (catalogue mean)": c["temp_mean_c"], f"{t['body']} reference": f"{ref['temp_min_c']} to {ref['temp_max_c']}"},
                                   {"Quantity": "Pressure (kPa)", "Earth site (catalogue mean)": "~101 (sea level)", f"{t['body']} reference": f"{ref['pressure_kpa']:.3g}"},
                                   {"Quantity": "Gravity (m/s²)", "Earth site (catalogue mean)": 9.81, f"{t['body']} reference": ref["gravity"]}]), hide_index=True)
    st.caption("The planetary side is a representative reference value, not a live measurement. Live weather is a snapshot and is kept out of the similarity score.")

with tabs[2]:
    st.markdown("#### Terrain cross-section comparison")
    st.caption("Schematic profiles generated from each site's morphology class and relief, normalised so shape (not absolute size) is compared. Replace with real DEM transects when available.")
    ang = st.slider("Transect angle (°)", 0, 170, 35, 5)
    th = np.radians(ang)
    a_, b_ = (0.5 - 0.45 * np.cos(th), 0.5 - 0.45 * np.sin(th)), (0.5 + 0.45 * np.cos(th), 0.5 + 0.45 * np.sin(th))
    hc, cc = dem.synthetic_dem(c["morphology"], relief_m=c["relief_m"], roughness=c["roughness"] or .3, seed=5)
    ht, ct = dem.synthetic_dem(t["morphology"], relief_m=t["relief_m"], roughness=t["roughness"] or .3, seed=9)
    dc, zc, sc_ = dem.transect(hc, cc, a_, b_); dt_, zt, st_ = dem.transect(ht, ct, a_, b_)
    st.plotly_chart(terrain_profiles({f"Earth: {c['name'].split(' (')[0]}": (dc, dem.normalised_profile(zc)),
                                      f"{t['body']}: {t['name'].split(' (')[0]}": (dt_, dem.normalised_profile(zt))}, "Normalised cross-sections"), theme=None)
    mc, mt = dem.terrain_metrics(hc, cc), dem.terrain_metrics(ht, ct)
    st.dataframe(pd.DataFrame({"Metric": ["Relief (m)", "Mean slope (°)", "Max slope (°)", "Steep fraction >20°", "Mean roughness (m)"],
                               "Earth site": [mc["relief_m"], mc["mean_slope_deg"], mc["max_slope_deg"], mc["steep_fraction_gt20"], mc["mean_roughness_m"]],
                               t["body"]: [mt["relief_m"], mt["mean_slope_deg"], mt["max_slope_deg"], mt["steep_fraction_gt20"], mt["mean_roughness_m"]]}).round(2), hide_index=True)

with tabs[3]:
    st.markdown("#### Spectral reflectance matcher")
    st.caption("Reference curves are SCHEMATIC (Gaussian absorption bands at commonly cited centres), not the USGS Spectral Library. Spectral resemblance is not definitive mineral identification.")
    x1, x2, x3 = st.columns(3)
    ma = x1.selectbox("Earth-site mineral", spectral.minerals(), index=spectral.minerals().index("olivine"))
    mb = x2.selectbox("Planetary-target mineral", spectral.minerals(), index=spectral.minerals().index("pyroxene"))
    cr_on = x3.toggle("Continuum removed view", value=False)
    ra, rb = spectral.spectrum(ma), spectral.spectrum(mb)
    if cr_on:
        ra, rb = spectral.continuum_removed(ra), spectral.continuum_removed(rb)
    fig = go.Figure()
    fig.add_trace(go.Scatter(x=spectral.WAVELENGTHS, y=ra, name=f"Earth: {ma}", line=dict(color=FROST, width=3)))
    fig.add_trace(go.Scatter(x=spectral.WAVELENGTHS, y=rb, name=f"Target: {mb}", line=dict(color=ICE, width=3, dash="dash")))
    fig.update_layout(title="Reflectance vs wavelength", xaxis_title="wavelength (nm)", yaxis_title="reflectance" + (" (continuum removed)" if cr_on else ""))
    st.plotly_chart(frost(fig, 400), theme=None)
    mt_ = spectral.match(ma, mb)
    m = st.columns(3)
    m[0].metric("Spectral angle", f"{mt_['angle_rad']:.3f} rad"); m[1].metric("Shape similarity", f"{mt_['similarity']:.2f}")
    m[2].metric("Band depth ≥ 8% (Earth)", len(spectral.absorption_bands(spectral.spectrum(ma))))
    st.markdown("**Identify an unknown spectrum**")
    u1, u2 = st.columns(2)
    unk = u1.selectbox("Simulated measurement of", spectral.minerals(), index=2)
    snr = u2.slider("Signal-to-noise", 5, 100, 30)
    ranked = spectral.rank_against_library(spectral.noisy_unknown(unk, snr))
    st.dataframe(pd.DataFrame(ranked, columns=["Library mineral", "Shape similarity"]), hide_index=True,
                 column_config={"Shape similarity": st.column_config.ProgressColumn(min_value=0, max_value=1, format="%.2f")})
    st.caption("Grain size, mixtures, illumination, atmosphere and calibration all change real spectra; treat matches as hypotheses.")

with tabs[4]:
    st.markdown("#### Seasonal deployment calendar")
    mon = live_monthly(c["lat"], c["lon"])
    if mon["ok"]:
        monthly, basis = mon["monthly"], f"Open-Meteo archive (ERA5-derived), year {mon['year']}"
    else:
        monthly, basis = estimate_monthly(c), "Offline sinusoidal estimate from catalogue statistics (NOT observed)"
    k1, k2 = st.columns(2)
    lo, hi = k1.slider("Comfortable temperature band (°C)", -40, 50, (-10, 30))
    plim = k2.slider("Precipitation limit (mm/month)", 10, 300, 80)
    sw = suitability_window(monthly, lo, hi, plim)
    fig = go.Figure()
    fig.add_trace(go.Bar(x=sw["month_name"], y=sw["suitability"], marker=dict(color=sw["suitability"], colorscale=[[0, "#293681"], [.5, BLUE], [1, FROST]], cmin=0, cmax=1,
                                                                           line=dict(color=FROST, width=1)), name="suitability"))
    fig.update_layout(title=f"Monthly suitability · {c['name']}", yaxis=dict(range=[0, 1]))
    st.plotly_chart(frost(fig, 340, False), theme=None)
    best = sw.sort_values("suitability", ascending=False).head(3)["month_name"].tolist()
    st.markdown(f"**Best-scoring months:** {', '.join(best)}.")
    st.caption(f"Basis: {basis}. A suitability window is a planning aid with uncertainty, not a weather forecast or guarantee.")

with tabs[5]:
    dims = st.multiselect("Dimensions", DIMENSIONS, default=DIMENSIONS, format_func=lambda d: DIMENSION_LABELS[d])
    if dims:
        st.plotly_chart(heatmap(rows, dims), theme=None)

with tabs[6]:
    st.markdown("#### Comparable geological processes")
    pe, pt = pd.DataFrame(processes_for(c)), pd.DataFrame(processes_for(t))
    if len(pe):
        shared = set(pe["Process"]) & set(pt["Process"]) if len(pt) else set()
        pe["Also at target?"] = pe["Process"].map(lambda p: "✓ yes" if p in shared else "not indicated")
        st.dataframe(pe, hide_index=True)
    else:
        st.info("No process tags recorded for this site.")
    st.markdown(f"**Target ({t['name'].split(' (')[0]}) processes:**")
    st.dataframe(pt, hide_index=True)
    st.caption("Process comparisons come from recorded lithology and mineral tags; a shared process does not imply an identical geological history.")

with tabs[7]:
    st.markdown("#### Resource and habitability indicators")
    hyd = ["gypsum", "clay", "jarosite", "sulfate", "carbonate", "halite", "perchlorate", "ice"]
    ri = pd.DataFrame([{"Site": x["name"], "Water/ice (0-1)": x["water_ice"], "Basis": x["water_basis"],
                        "Hydrated / salt minerals": ", ".join(m for m in x["minerals"] if m in hyd) or "-", "Biology index": x["biology"],
                        "Confidence": "direct" if x["water_basis"] == "observed" else "proxy/inferred"} for x in ctx["cand_list"]])
    st.dataframe(ri.sort_values("Water/ice (0-1)", ascending=False), hide_index=True,
                 column_config={"Water/ice (0-1)": st.column_config.ProgressColumn(min_value=0, max_value=1, format="%.2f")})
    st.caption("Indicators are proxies of resource or habitability potential, not confirmed resources. Low biology is better for sterile-analogue work, higher for astrobiology.")
