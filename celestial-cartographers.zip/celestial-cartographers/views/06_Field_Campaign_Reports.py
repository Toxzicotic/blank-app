import streamlit as st

from components.context import sidebar
from components.theme import hero, seed_banner
from config import scoring_config as cfg
from config.mission_presets import DIMENSION_LABELS, DIMENSIONS
from reports import generators as gen
from scientific_engine.explain import explain

ctx = sidebar()
t, rows, cands, obj, weights = ctx["target"], ctx["rows"], ctx["cands"], ctx["objective"], ctx["weights"]

hero("Field Campaign Reports", "Explanations for every ranked site, full provenance, and exportable cited briefs (PDF, Markdown, CSV, GeoJSON).",
     eyebrow="Workspace 06", pills=["explainable", "provenance", "export"])
seed_banner()

st.markdown("#### Why was each site selected?")
pick = st.selectbox("Site", [r["name"] for r in rows])
r = next(x for x in rows if x["name"] == pick)
c = cands[r["id"]]
ex = explain(t, c, r, obj)
a, b = st.columns([1.5, 1])
with a:
    for q, items in ex.items():
        with st.expander(q, expanded=q.startswith("Why")):
            for i in items:
                st.markdown(f"- {i}")
with b:
    with st.container(key="glass_prov"):
        st.markdown("#### Provenance")
        st.write(f"**Status:** {c['status']}  ·  **Scale:** {c['scale']}")
        st.write(f"**Coordinates:** {c['lat']}, {c['lon']}")
        st.write(f"**Nominal resolution:** {c['resolution_m']} m  ·  **Data quality:** {c['data_quality']:.0%}")
        st.write(f"**Value basis:** {c['basis']}")
        st.write("**Datasets:**")
        for s in c["sources"]:
            st.markdown(f"- {s}")
        st.write(f"**Coverage of weighted dimensions:** {r['coverage']:.0%}")
        miss = ", ".join(DIMENSION_LABELS[d] for d in r["missing_dimensions"]) or "none"
        st.write(f"**Missing:** {miss}")
        st.caption(f"Model {cfg.MODEL_VERSION} · data {cfg.DATA_VERSION}")

st.markdown("#### Export")
top_n = st.slider("Detailed write-ups for top N sites", 1, min(8, len(rows)), 3)
st.caption(gen.DISCLAIMER)
e1, e2, e3, e4 = st.columns(4)
e1.download_button("⬇ PDF brief", data=gen.to_pdf(rows, cands, t, obj, weights, top_n), file_name="campaign_brief.pdf", mime="application/pdf")
e2.download_button("⬇ Markdown", data=gen.to_markdown(rows, cands, t, obj, weights, top_n), file_name="campaign_brief.md", mime="text/markdown")
e3.download_button("⬇ CSV table", data=gen.to_csv(rows, cands), file_name="candidates.csv", mime="text/csv")
e4.download_button("⬇ GeoJSON", data=gen.to_geojson(rows, cands, t, obj, weights), file_name="candidates.geojson", mime="application/geo+json")

with st.expander("Preview the Markdown brief"):
    st.markdown(gen.to_markdown(rows, cands, t, obj, weights, top_n))
