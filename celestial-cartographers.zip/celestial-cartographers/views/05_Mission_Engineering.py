import numpy as np
import pandas as pd
import plotly.graph_objects as go
import streamlit as st

from components import three_views as tv
from components.charts import frost
from components.context import sidebar
from components.theme import BLUE, FROST, ICE, hero, seed_banner
from config.mission_presets import DIMENSION_LABELS, DIMENSIONS
from config.planetary_constants import PLANETS
from optimization.campaign import campaign_coverage, route_length_km, select_campaign
from scientific_engine import dem
from simulations import drilling, rover

ctx = sidebar()
t, rows, cands, obj, weights = ctx["target"], ctx["rows"], ctx["cands"], ctx["objective"], ctx["weights"]
g_t = PLANETS[t["body"]]["gravity"]

hero("Mission Engineering", "Estimate loads, sinkage, traverses, drilling energy and multi-site campaigns. Idealised models, clearly labelled.",
     eyebrow="Workspace 05", pills=["gravity offload", "traverse planner", "drilling", "campaign optimiser"])
seed_banner()
st.markdown("<div class='banner'>Engineering outputs are <b>test-planning estimates</b>, not validated hardware predictions. Each tool lists what it omits.</div>", unsafe_allow_html=True)

tabs = st.tabs(["Gravity offload & wheel-soil", "Traverse planner (3D)", "Drilling energy", "Subsurface context", "Campaign optimiser", "Suitability table"])

with tabs[0]:
    a, b = st.columns([1, 1.4])
    with a:
        mass = st.number_input("Rover / payload mass (kg)", 5.0, 2000.0, 120.0)
        wheels = st.slider("Wheels", 3, 8, 4)
        wr = st.number_input("Wheel radius (m)", 0.05, 0.6, 0.2, 0.01)
        wb = st.number_input("Wheel width (m)", 0.03, 0.5, 0.12, 0.01)
        slope = st.slider("Slope (°)", 0, 30, 10)
        soil = st.selectbox("Soil model", list(rover.SOILS))
    out = rover.gravity_offload(mass, wheels, wr, wb, g_t, slope, soil)
    with b:
        m = st.columns(2)
        m[0].metric("Offload force needed", f"{out['offload_force_N']:.0f} N", f"≈ {out['offload_mass_equivalent_kg']:.0f} kg equiv.")
        m[1].metric(f"Normal load on {t['body']}", f"{out['normal_load_target_N']:.0f} N", f"Earth {out['normal_load_earth_N']:.0f} N")
        m = st.columns(2)
        m[0].metric("Torque / wheel (target)", f"{out['torque_per_wheel_target_Nm']:.1f} N·m", f"Earth {out['torque_per_wheel_earth_Nm']:.1f}")
        m[1].metric("Bekker sinkage (target)", f"{out['sinkage_target_mm']:.1f} mm", f"Earth {out['sinkage_earth_mm']:.1f} mm")
        fig = go.Figure(go.Bar(x=["Earth", t["body"]], y=[out["sinkage_earth_mm"], out["sinkage_target_mm"]], marker_color=[ICE, FROST], text=[f"{out['sinkage_earth_mm']:.1f}", f"{out['sinkage_target_mm']:.1f}"], textposition="outside"))
        fig.update_layout(title="Estimated wheel sinkage (mm)")
        st.plotly_chart(frost(fig, 280, False), theme=None)
    st.caption("Formulas: N = m·g·cosθ, offload = N_Earth − N_target, T = F·r per wheel (grade only), Bekker p = (k_c/b + k_φ)·zⁿ solved for z. "
               "Soil parameters are illustrative. Omitted: " + "; ".join(out["omitted"]) + ".")

with tabs[1]:
    c1, c2 = st.columns([1, 2.3])
    with c1:
        kind = st.selectbox("Terrain morphology", ["crater", "valley", "volcanic", "lava_tube", "flat"], index=["crater", "valley", "volcanic", "lava_tube", "flat"].index(t["morphology"]) if t["morphology"] in ["crater", "valley", "volcanic", "lava_tube", "flat"] else 0, key="trav_kind")
        n = 72
        seed = st.number_input("Terrain seed", 1, 99, 3)
        max_slope = st.slider("Max traversable slope (°)", 5, 35, 20)
        sr, sc = st.slider("Start row", 0, n - 1, 6), st.slider("Start column", 0, n - 1, 6)
        gr, gc = st.slider("Goal row", 0, n - 1, n - 8), st.slider("Goal column", 0, n - 1, n - 8)
        mass2 = st.number_input("Rover mass (kg)", 5.0, 1000.0, 150.0, key="m2")
        soil2 = st.selectbox("Rolling-resistance soil", list(rover.SOILS), key="soil2")
    h, cell = dem.synthetic_dem(kind, n=n, size_m=1500, relief_m=max(t["relief_m"] / 6, 60), roughness=t["roughness"], seed=int(seed))
    sl = dem.slope_deg(h, cell)
    path = rover.astar(sl, cell, (sr, sc), (gr, gc), max_slope)
    with c2:
        if path is None:
            st.error("No traversable route under the slope limit. Raise the limit or move start/goal.")
            tv.show(tv.terrain_html(h, info="no route"), 520)
        else:
            stt = rover.path_stats(h, cell, path, mass2, g_t, rover.SOILS[soil2]["crr"])
            cov = rover.comms_coverage(h, cell, path, (sr, sc))
            tv.show(tv.terrain_html(h, info=f"<b>Traverse</b><br><span style='color:{ICE}'>{stt['distance_m']:.0f} m · {len(path)} cells</span>", path=path, lander=(sr, sc), exag=1.2), 520)
            m = st.columns(4)
            m[0].metric("Distance", f"{stt['distance_m']:.0f} m"); m[1].metric("Elevation gain", f"{stt['elevation_gain_m']:.0f} m")
            m[2].metric("Energy", f"{stt['energy_Wh']:.0f} Wh"); m[3].metric("Line-of-sight to lander", f"{cov:.0%}")
    if path is not None:
        fig = go.Figure(go.Heatmap(z=sl, colorscale=[[0, "#293681"], [.4, BLUE], [.75, ICE], [1, FROST]], colorbar=dict(title="slope °", tickfont=dict(color=FROST))))
        fig.add_trace(go.Scatter(x=[p[1] for p in path], y=[p[0] for p in path], mode="lines", line=dict(color="#ffffff", width=3), name="route"))
        fig.update_layout(title="Slope map with A* route", xaxis=dict(range=[-0.5, n - 0.5], constrain="domain"), yaxis=dict(range=[n - 0.5, -0.5], scaleanchor="x", constrain="domain"))
        st.plotly_chart(frost(fig, 440), theme=None)
    st.caption(f"A* over a slope-based cost surface on SCHEMATIC terrain, gravity {g_t} m/s², no energy regeneration. Line-of-sight is geometric (3 m lander mast, 1.5 m rover mast), ignoring curvature and diffraction.")

with tabs[2]:
    a, b = st.columns([1, 1.4])
    with a:
        medium = st.selectbox("Medium", list(drilling.MEDIA))
        lo, hi = drilling.MEDIA[medium]
        depth = st.number_input("Depth (m)", 0.1, 100.0, 2.0)
        dia = st.number_input("Hole diameter (m)", 0.01, 0.5, 0.05, 0.005)
        rate = st.number_input("Rate (m/h)", 0.01, 20.0, 0.5)
        se = st.slider("Specific energy (MJ/m³)", float(lo), float(hi), float((lo + hi) / 4))
        eff = st.slider("Drive efficiency", 0.05, 0.9, 0.25)
    d = drilling.drilling_estimate(depth, dia, rate, medium, se, eff)
    with b:
        m = st.columns(3)
        m[0].metric("Energy", f"{d['energy_Wh']:.1f} Wh"); m[1].metric("Duration", f"{d['duration_h']:.1f} h"); m[2].metric("Mean power", f"{d['mean_power_W']:.1f} W")
        st.write(f"Range across plausible specific energies for **{medium}**: {d['range_Wh'][0]:.1f} – {d['range_Wh'][1]:.1f} Wh.")
        st.caption("Specific energy values are user-adjustable placeholders spanning wide ranges, not calibrated for any real drill. Order-of-magnitude planning only.")

with tabs[3]:
    st.markdown("#### Cave and subsurface candidates")
    cv = pd.DataFrame([{"Site": x["name"], "Cave evidence": x["caves"], "Stable temp range (°C)": f"{x['temp_min_c']} to {x['temp_max_c']}", "Relief (m)": x["relief_m"],
                        "Operations": x["operations"]} for x in ctx["cand_list"] if (x["caves"] or 0) >= 0.3]).sort_values("Cave evidence", ascending=False)
    st.dataframe(cv, hide_index=True, column_config={"Cave evidence": st.column_config.ProgressColumn(min_value=0, max_value=1, format="%.2f")})
    h, cell = dem.synthetic_dem("lava_tube", n=72, size_m=600, relief_m=40)
    tv.show(tv.terrain_html(h, info="<b>Lava-tube collapse trench</b><br>schematic skylight pits", exag=2.2), 440)
    st.caption("Cave evidence is inferred, and an unknown value is not absence. Interior thermal stability and radiation shielding are subsurface hypotheses to verify, "
               f"for target {t['name'].split(' (')[0]} (cave evidence {t['caves']}).")

with tabs[4]:
    k = st.slider("Sites in campaign", 2, 5, 3)
    lw = st.slider("Logistics weight", 0.0, 0.6, 0.25, 0.05)
    ch = select_campaign(rows, cands, weights, k, lw)
    st.dataframe(pd.DataFrame([{"Order": x["order"], "Site": x["name"], "Marginal gain": round(x["marginal_gain"], 3),
                                "Adds coverage in": ", ".join(DIMENSION_LABELS[d] for d in x["new_coverage"]) or "-"} for x in ch]), hide_index=True)
    cov = campaign_coverage(ch, rows)
    fig = go.Figure(go.Bar(x=[DIMENSION_LABELS[d] for d in DIMENSIONS], y=[cov[d] or 0 for d in DIMENSIONS], marker_color=ICE, marker_line=dict(color=FROST, width=1)))
    fig.update_layout(title="Best coverage achieved per dimension across the campaign", yaxis=dict(range=[0, 1]))
    st.plotly_chart(frost(fig, 320, False), theme=None)
    st.metric("Great-circle route length (visit order)", f"{route_length_km([x['id'] for x in ch], cands):,.0f} km")
    st.caption("Greedy complementary selection: each pick adds the most new weighted coverage, discounted by access difficulty. Not a proven global optimum; "
               "route length ignores real travel, permits and weather.")

with tabs[5]:
    st.dataframe(pd.DataFrame([{"Site": r["name"], "Mission suitability": r["suitability"], "Operations": cands[r["id"]]["operations"], "Slope (°)": cands[r["id"]]["slope_deg"],
                                "Analogue fidelity": r["fidelity"]} for r in rows]).sort_values("Mission suitability", ascending=False), hide_index=True,
                 column_config={"Mission suitability": st.column_config.ProgressColumn(min_value=0, max_value=1, format="%.2f"),
                                "Analogue fidelity": st.column_config.ProgressColumn(min_value=0, max_value=1, format="%.2f")})
    st.caption("Suitability (access and terrain safety) is independent of how closely a site resembles the target.")
