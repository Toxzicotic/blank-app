import numpy as np
import pandas as pd
import plotly.graph_objects as go
import streamlit as st

from components import three_views as tv
from components.charts import candidate_map, frost
from components.context import live_current, live_monthly, live_quakes, sidebar
from components.theme import FROST, ICE, hero, seed_banner
from data_sources.live_earth import GIBS_LAYERS, gibs_tile_url
from scientific_engine import dem
from scientific_engine.seasonal import estimate_monthly

ctx = sidebar()
t, rows, cands = ctx["target"], ctx["rows"], ctx["cands"]

hero("Planetary Explorer", "Inspect the target's environmental fingerprint, explore 3D terrain, and watch near-real-time Earth conditions.",
     eyebrow="Workspace 02", pills=[t["body"], t["name"].split(" (")[0], "live Earth feeds"])
seed_banner()

tab_fp, tab_map, tab_3d, tab_live, tab_time = st.tabs(["Target fingerprint", "Map & layers", "3D terrain", "Live Earth conditions", "Temporal layer"])

# ---------------------------------------------------------------------------------------------
with tab_fp:
    st.markdown(f"#### Environmental fingerprint · {t['name']}")
    src = "; ".join(t["sources"])
    fp = [
        ("Elevation relief", f"{t['relief_m']} m", "DEM statistics, elevation profile"),
        ("Slope (typical)", f"{t['slope_deg']}°", "Slope layer, histogram, steep-area mask"),
        ("Surface roughness", f"{t['roughness']} (0-1)", "Roughness layer and summary metrics"),
        ("Geological composition", f"{t['lithology']}; " + ", ".join(t["minerals"]), "Geological map / mineral indicators"),
        ("Crater / volcanic / morphology", f"{t['scale']} · {t['morphology']}", "Terrain classes and descriptors"),
        ("Temperature", f"mean {t['temp_mean_c']} °C, range {t['temp_min_c']} to {t['temp_max_c']} °C", "Thermal layer, range"),
        ("Water/ice indicator", f"{t['water_ice']} ({t['water_basis']})", "Observation/proxy layer with confidence caveat"),
        ("Dust", f"{t['dust']} (0-1)", "Dust indicators"),
        ("Cave / subsurface evidence", f"{t['caves']} (0-1)", "Subsurface candidates"),
    ]
    st.dataframe(pd.DataFrame(fp, columns=["Parameter", "Value (seed estimate)", "Display / output"]), hide_index=True)
    c = st.columns(3)
    c[0].metric("Nominal resolution", f"{t['resolution_m']} m")
    c[1].metric("Data quality", f"{t['data_quality']:.0%}")
    c[2].metric("Coordinates", f"{t['lat']}°, {t['lon']}°")
    st.caption(f"Provenance: {src}. Basis: {t['basis']} (hand-compiled demonstration values). "
               "Each real layer must record source, date, resolution, CRS, units and processing level.")

# ---------------------------------------------------------------------------------------------
with tab_map:
    st.markdown("#### Earth candidates and live satellite imagery")
    l, r = st.columns([1, 3])
    with l:
        use_gibs = st.toggle("NASA GIBS imagery overlay", value=False, help="Near-real-time imagery tiles fetched by your browser from NASA GIBS.")
        layer = st.selectbox("Layer", list(GIBS_LAYERS), disabled=not use_gibs)
        days = st.slider("Days back", 1, 7, 2, disabled=not use_gibs, help="Imagery is processed with a lag; 1-2 days is usually available.")
        st.caption("Layer provenance for the overlay: NASA GIBS WMTS, EPSG:3857, daily composite. Cloud and processing gaps are normal.")
    with r:
        g = gibs_tile_url(layer, days) if use_gibs else None
        fig = candidate_map(ctx["cand_list"], {x["id"]: x["total"] for x in rows}, gibs_url=g["url"] if g else None)
        st.plotly_chart(fig, theme=None)
    if g:
        st.caption(f"Overlay: {g['layer']} · acquisition date {g['date']} · tiles load from gibs.earthdata.nasa.gov (needs internet in your browser).")
    st.markdown(f"#### {t['body']} target globe")
    tm = [{"name": x["name"], "lat": x["lat"], "lon": x["lon"], "value": 1.0 if x["id"] == t["id"] else 0.3, "line": x["lithology"],
           "selected": x["id"] == t["id"], "isTarget": x["id"] == t["id"]} for x in __import__("data_sources.seed_catalog", fromlist=["TARGETS"]).TARGETS if x["body"] == t["body"]]
    tv.show(tv.globe_html(t["body"], tm, focus=(t["lat"], t["lon"]), title=f"{t['body']} · procedural surface (schematic)"), 480)
    st.caption("The Moon/Mars globes use a procedural schematic surface, not real imagery. Real Moon/Mars tiles would come from NASA Trek services.")

# ---------------------------------------------------------------------------------------------
with tab_3d:
    st.markdown("#### 3D terrain and micro-site navigation")
    a, b = st.columns([1, 2.4])
    with a:
        site = st.selectbox("Site", ["Target: " + t["name"]] + [x["name"] for x in ctx["cand_list"]])
        rec = t if site.startswith("Target") else next(x for x in ctx["cand_list"] if x["name"] == site)
        kind = st.selectbox("Morphology", ["crater", "volcanic", "valley", "lava_tube", "flat"],
                            index=["crater", "volcanic", "valley", "lava_tube", "flat"].index(rec["morphology"]))
        up = st.file_uploader("Or upload a real DEM (GeoTIFF / ASCII grid)", type=["tif", "tiff", "asc", "txt"])
        exag = st.slider("Initial vertical exaggeration", 0.5, 3.0, 1.6, 0.1)
    h, cell, msg = None, 0.0, ""
    if up is not None:
        h, cell, msg = dem.load_uploaded_dem(up.name, up.getvalue())
        if h is None:
            st.error(msg)
    if h is None:
        h, cell = dem.synthetic_dem(kind, relief_m=float(rec["relief_m"]), roughness=float(rec["roughness"] or 0.3), size_m=max(rec["relief_m"] * 8, 800))
        msg = "SCHEMATIC terrain generated from the site's morphology class and relief. Not measured data."
    met = dem.terrain_metrics(h, cell)
    with b:
        tv.show(tv.terrain_html(h, info=f"<b>{rec['name'].split(' (')[0]}</b><br><span style='color:{ICE}'>{kind} · relief {met['relief_m']:.0f} m</span>", exag=exag), 560)
    st.caption(msg)
    m = st.columns(5)
    m[0].metric("Relief", f"{met['relief_m']:.0f} m"); m[1].metric("Mean slope", f"{met['mean_slope_deg']:.1f}°")
    m[2].metric("Max slope", f"{met['max_slope_deg']:.0f}°"); m[3].metric("Steep fraction >20°", f"{met['steep_fraction_gt20']:.0%}")
    m[4].metric("Cell size", f"{met['cell_size_m']:.1f} m")
    st.caption("When using real data, record DEM resolution, vertical datum and resampling method (blueprint 3.3).")

# ---------------------------------------------------------------------------------------------
with tab_live:
    st.markdown("#### Live (near-real-time) Earth conditions")
    names = [x["name"] for x in ctx["cand_list"]]
    pick = st.selectbox("Earth site", names, index=names.index(rows[0]["name"]), key="live_site")
    cc = next(x for x in ctx["cand_list"] if x["name"] == pick)
    cur = live_current(cc["lat"], cc["lon"])
    q = live_quakes(cc["lat"], cc["lon"], 300.0)
    if cur["ok"]:
        st.markdown(f"<span class='pill ice'>● LIVE</span><span class='tiny'>observed {cur['observed_time']} UTC · fetched {cur['fetched_utc']} · {cur['source']}</span>", unsafe_allow_html=True)
        m = st.columns(5)
        m[0].metric("Temperature", f"{cur['temperature_c']:.1f} °C"); m[1].metric("Surface pressure", f"{cur['pressure_kpa']:.1f} kPa")
        m[2].metric("Wind", f"{cur['wind_ms']:.1f} m/s"); m[3].metric("Cloud cover", f"{cur['cloud_pct']}%")
        m[4].metric("Solar", f"{cur['solar_wm2']:.0f} W/m²")
        T = t
        within = T["temp_min_c"] <= cur["temperature_c"] <= T["temp_max_c"]
        st.markdown(f"**Versus {t['name'].split(' (')[0]}:** the site is currently {'inside' if within else 'outside'} the target's temperature range "
                    f"({T['temp_min_c']} to {T['temp_max_c']} °C); pressure is {cur['pressure_kpa'] / 0.6:.0f}× Mars-like or effectively infinite× lunar. "
                    "Live weather is a snapshot, not the site's climate, and is excluded from the similarity score.")
    else:
        st.warning(f"Live feed unavailable right now ({cur.get('error', 'no response')}). The app runs fully offline with catalogue values; "
                   "reconnect to see live conditions.")
    st.markdown("##### Seismic activity within 300 km (USGS, past 7 days)")
    if q["ok"]:
        st.caption(f"{q['source']} · fetched {q['fetched_utc']}")
        st.dataframe(pd.DataFrame(q["events"][:15]) if q["events"] else pd.DataFrame({"result": ["No events in range"]}), hide_index=True)
    else:
        st.info(f"Earthquake feed unavailable ({q.get('error', '')}).")
    if st.button("Refresh now"):
        live_current.clear(); live_quakes.clear(); st.rerun()
    st.caption("Latency by source: Open-Meteo hourly · USGS minutes · NASA GIBS hours to a day · ERA5-derived archive a few days. "
               "The Moon and Mars have no live feed here; their values are reference ranges.")

# ---------------------------------------------------------------------------------------------
with tab_time:
    st.markdown("#### Temporal layer: seasonal temperature")
    pick2 = st.selectbox("Earth site", [x["name"] for x in ctx["cand_list"]], key="time_site")
    c2 = next(x for x in ctx["cand_list"] if x["name"] == pick2)
    mon = live_monthly(c2["lat"], c2["lon"])
    if mon["ok"]:
        df = mon["monthly"]; basis = f"Open-Meteo archive (ERA5-derived), year {mon['year']} · fetched {mon['fetched_utc']}"
        daily = mon["daily"]
        fig = go.Figure(go.Scatter(x=daily["time"], y=daily["temperature_2m_mean"], mode="lines", line=dict(color=FROST, width=1.6), name="daily mean"))
        fig.update_layout(title=f"Daily mean temperature, {pick2}", yaxis_title="°C")
        st.plotly_chart(frost(fig, 340, False), theme=None)
    else:
        df = estimate_monthly(c2); basis = "Offline estimate from catalogue statistics (sinusoidal); NOT observed data."
        st.warning(f"Archive unavailable ({mon.get('error', '')}). Showing a catalogue-based estimate.")
    if len(df):
        fig = go.Figure()
        fig.add_trace(go.Scatter(x=df["month"], y=df["temp_max_c"], line=dict(color=ICE, dash="dot"), name="max"))
        fig.add_trace(go.Scatter(x=df["month"], y=df["temp_min_c"], line=dict(color=ICE, dash="dot"), name="min", fill="tonexty", fillcolor="rgba(149,204,221,.15)"))
        fig.add_trace(go.Scatter(x=df["month"], y=df["temp_mean_c"], line=dict(color=FROST, width=3), name="mean"))
        fig.update_layout(title="Monthly temperature envelope", xaxis=dict(tickmode="array", tickvals=list(range(1, 13)), ticktext=["J", "F", "M", "A", "M", "J", "J", "A", "S", "O", "N", "D"]))
        st.plotly_chart(frost(fig, 340), theme=None)
    st.caption(basis + ". Temporal patterns can inform process comparisons but do not establish identical geological histories.")
