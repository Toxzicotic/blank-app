# Celestial Cartographers

Planetary-analogue discovery and mission-planning platform (NASA Space Apps Challenge 2026), built from the technical blueprint.
Streamlit app with a frosted-glass UI (palette `#293681 #4274D9 #95CCDD #D0E7E6`) and embedded Three.js 3D scenes.

## Run

```bash
python -m venv .venv && source .venv/bin/activate      # Windows: .venv\Scripts\activate
pip install -r requirements.txt
streamlit run app.py                                    # http://localhost:8501
pytest                                                  # 19 tests (engine + every page runs headlessly)
```
Docker: `docker compose up --build`. No API keys are needed. Three.js is bundled (`assets/vendor`), so the 3D scenes work offline.
Optional extras (rasterio for GeoTIFF upload, earthaccess, torch, FastAPI...) are in `requirements-optional.txt`.

## Pages (blueprint workspaces)

| Page | What it does |
|---|---|
| Overview | Hero, 3D Earth globe of candidates (marker size/colour = similarity) and a 3D Moon/Mars target globe |
| 01 Mission Control | Target + objective, editable weights, ranking overview, always-visible limitations, data coverage |
| 02 Planetary Explorer | Target fingerprint, candidate map with NASA GIBS imagery overlay, 3D terrain (synthetic or uploaded DEM), live Earth conditions, temporal layer |
| 03 Analog Discovery Lab | 8-dimension ranker, radar/bar/score charts, global atlas (map + 3D), sensitivity & uncertainty, custom search, dataset fusion, environment clusters, Moon-vs-Mars |
| 04 Scientific Comparison | Condition scorecard, live-vs-reference, terrain cross-sections, spectral matcher, seasonal calendar, heatmap, processes, resource indicators |
| 05 Mission Engineering | Gravity offload + Bekker sinkage, 3D traverse planner (A*, energy, line-of-sight), drilling energy, subsurface, campaign optimiser |
| 06 Field Campaign Reports | Five-question explanations, provenance, PDF / Markdown / CSV / GeoJSON export |
| 07 AI Research Assistant | Dataset-grounded Q&A (no LLM), cites datasets, refuses what the data cannot support |

## Read this before trusting any number

* **The catalogue is seed data.** `data_sources/seed_catalog.py` holds approximate, hand-compiled demonstration values for 7 targets and 12 Earth sites. They are not measurements and not pipeline output (blueprint 11.1). Replace them with LOLA/MOLA/SRTM/MODIS-derived features before drawing scientific conclusions.
* Scores are similarity indices, **not probabilities**. Fidelity, suitability and transferability are kept separate; transferability is a heuristic.
* Dimension weights (except the two in the blueprint table) are placeholders.
* Moon/Mars globes and the default terrain are procedural/schematic, spectra are schematic Gaussian bands (not the USGS library), and engineering models are idealised test-planning estimates. Each page says what it omits.
* "Live" = near-real-time: Open-Meteo (hourly), USGS (minutes), NASA GIBS (hours-day). The Moon/Mars side is always a reference value. The app degrades gracefully offline.

## Not implemented in this build

CNN/U-Net terrain classification (needs labelled imagery), FastAPI service, PostGIS database, Celery/Redis, CesiumJS globe, real Moon/Mars imagery tiles, and any LLM in the assistant. Hooks exist: `ai/assistant.py::answer` is the single integration point for an LLM that must use only the retrieved evidence.

## Layout

`config/` presets & constants · `data_sources/` seed catalogue + live feeds · `scientific_engine/` similarity, DEM, spectral, seasonal, explanations · `simulations/` rover, drilling · `optimization/` campaign · `ai/` assistant, clustering · `reports/` exports · `components/` theme, charts, Three.js · `views/` the pages · `tests/`.
