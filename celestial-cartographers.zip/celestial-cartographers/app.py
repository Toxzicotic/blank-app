"""Celestial Cartographers - entry point (Streamlit multipage app).

Run:  streamlit run app.py
"""
import streamlit as st

from components.theme import apply_theme

st.set_page_config(page_title="Celestial Cartographers", page_icon="🛰️", layout="wide", initial_sidebar_state="expanded")
apply_theme()

pg = st.navigation(
    [
        st.Page("views/00_Home.py", title="Overview", icon="🌐", default=True),
        st.Page("views/01_Mission_Control.py", title="Mission Control", icon="🎛️"),
        st.Page("views/02_Planetary_Explorer.py", title="Planetary Explorer", icon="🪐"),
        st.Page("views/03_Analog_Discovery_Lab.py", title="Analog Discovery Lab", icon="🔭"),
        st.Page("views/04_Scientific_Comparison.py", title="Scientific Comparison", icon="⚖️"),
        st.Page("views/05_Mission_Engineering.py", title="Mission Engineering", icon="🛠️"),
        st.Page("views/06_Field_Campaign_Reports.py", title="Field Campaign Reports", icon="📄"),
        st.Page("views/07_AI_Research_Assistant.py", title="AI Research Assistant", icon="💬"),
    ],
    position="top",
)
pg.run()
