"""Frosted-glass ("frost mirror") theme.

Palette (user supplied): #293681 deep indigo, #4274D9 blue, #95CCDD ice, #D0E7E6 frost.
Everything else is a tint/shade/alpha of those four.
"""
from __future__ import annotations

import streamlit as st

INK = "#293681"
BLUE = "#4274D9"
ICE = "#95CCDD"
FROST = "#D0E7E6"
DEEP = "#1d2766"      # darker shade of INK for depth

_NOISE = ("url(\"data:image/svg+xml;utf8,%3Csvg xmlns='http://www.w3.org/2000/svg' width='220' height='220'%3E%3Cfilter id='n'%3E"
          "%3CfeTurbulence type='fractalNoise' baseFrequency='.85' numOctaves='2' stitchTiles='stitch'/%3E%3C/filter%3E"
          "%3Crect width='100%25' height='100%25' filter='url(%23n)'/%3E%3C/svg%3E\")")

CSS = f"""
@import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600&family=Space+Grotesk:wght@500;600;700&display=swap');
:root {{
  --ink:{INK}; --blue:{BLUE}; --ice:{ICE}; --frost:{FROST}; --deep:{DEEP};
  --glass: linear-gradient(135deg, rgba(208,231,230,.20) 0%, rgba(149,204,221,.08) 45%, rgba(208,231,230,.12) 100%);
  --glass-border: rgba(208,231,230,.38);
  --shadow: 0 10px 40px rgba(14,20,70,.45), inset 0 1px 0 rgba(255,255,255,.35), inset 0 -1px 0 rgba(149,204,221,.15);
}}
html, body, .stApp, [class*="css"] {{ font-family: 'Inter', 'Segoe UI', system-ui, sans-serif; }}
h1, h2, h3, h4 {{ font-family: 'Space Grotesk', 'Inter', sans-serif; letter-spacing: -.01em; color: var(--frost); }}
.stApp {{
  color: var(--frost);
  background:
    radial-gradient(900px 620px at 8% -8%, rgba(149,204,221,.38), transparent 62%),
    radial-gradient(820px 720px at 104% 8%, rgba(66,116,217,.62), transparent 58%),
    radial-gradient(760px 700px at 48% 112%, rgba(149,204,221,.22), transparent 62%),
    linear-gradient(160deg, #293681 0%, #243079 55%, {DEEP} 100%);
  background-attachment: fixed;
}}
.stApp::before {{ /* frost grain */
  content:""; position:fixed; inset:0; pointer-events:none; z-index:0; opacity:.10; mix-blend-mode:overlay; background-image:{_NOISE};
}}
[data-testid="stHeader"] {{ background: transparent; }}
[data-testid="stAppViewContainer"] .main .block-container {{ padding-top: 2.2rem; max-width: 1280px; position:relative; z-index:1; }}

/* glass surfaces */
.glass, [class*="st-key-glass"], [data-testid="stMetric"], [data-testid="stExpander"] details,
[data-testid="stAlert"], [data-testid="stForm"], .stTabs [data-baseweb="tab-panel"] {{
  background: var(--glass) !important;
  border: 1px solid var(--glass-border) !important;
  border-radius: 20px !important;
  box-shadow: var(--shadow);
  backdrop-filter: blur(20px) saturate(150%);
  -webkit-backdrop-filter: blur(20px) saturate(150%);
}}
[class*="st-key-glass"] {{ padding: 1.1rem 1.25rem; }}
.stTabs [data-baseweb="tab-panel"] {{ padding: 1.1rem 1.25rem; margin-top: .6rem; }}
[data-testid="stMetric"] {{ padding: .9rem 1.1rem; }}
[data-testid="stMetricLabel"] p {{ color: var(--ice); font-size: .78rem; letter-spacing:.08em; text-transform: uppercase; }}
[data-testid="stMetricValue"] {{ color: var(--frost); font-family:'Space Grotesk',sans-serif; font-size: 1.9rem; }}
[data-testid="stMetricValue"] > div {{ white-space: normal !important; overflow: visible !important; text-overflow: clip !important; line-height: 1.15; }}
[data-testid="stMetricDelta"] {{ color: var(--ice) !important; background: rgba(149,204,221,.16) !important; border-radius: 999px; padding: .05rem .55rem; width: fit-content; }}
[data-testid="stMetricDelta"] svg {{ fill: var(--ice) !important; }}
[data-testid="stAlert"] {{ color: var(--frost); }}
[data-testid="stExpander"] summary {{ color: var(--frost); }}

.hero {{ position:relative; overflow:hidden; padding: 2.2rem 2.4rem; border-radius: 28px; margin-bottom: 1.2rem; }}
.hero::after {{ /* diagonal frost glint */
  content:""; position:absolute; top:-60%; left:-20%; width:55%; height:240%;
  background: linear-gradient(100deg, transparent 30%, rgba(255,255,255,.16) 50%, transparent 70%); transform: rotate(8deg); pointer-events:none; }}
.hero h1 {{ font-size: 2.6rem; margin: 0 0 .35rem 0; line-height:1.05; }}
.hero p {{ color: var(--ice); margin: 0; font-size: 1.02rem; }}
.eyebrow {{ text-transform: uppercase; letter-spacing: .22em; font-size: .72rem; color: var(--ice); margin-bottom: .6rem; }}
.pill {{ display:inline-block; padding:.18rem .7rem; border-radius:999px; font-size:.74rem; margin-right:.4rem;
  border:1px solid var(--glass-border); background: rgba(208,231,230,.12); color: var(--frost); }}
.pill.ice {{ background: rgba(149,204,221,.28); }}
.pill.warn {{ border-style: dashed; }}
.banner {{ padding:.7rem 1rem; border-radius:14px; border:1px dashed var(--glass-border); background: rgba(29,39,102,.45);
  color: var(--frost); font-size:.86rem; margin-bottom: 1rem; }}
.status-match {{ color: var(--frost); }} .status-partial {{ color: var(--ice); }}
.tiny {{ font-size:.78rem; color: var(--ice); }}

/* sidebar */
section[data-testid="stSidebar"] {{
  background: linear-gradient(180deg, rgba(41,54,129,.62), rgba(29,39,102,.72)) !important;
  border-right: 1px solid var(--glass-border); backdrop-filter: blur(22px) saturate(140%); }}
section[data-testid="stSidebar"] * {{ color: var(--frost); }}
[data-testid="stSidebarNav"] a {{ border-radius: 12px; }}
[data-testid="stSidebarNav"] a[aria-current="page"] {{ background: rgba(208,231,230,.18); border: 1px solid var(--glass-border); }}

/* inputs */
[data-baseweb="select"] > div, [data-baseweb="input"] > div, textarea, .stTextInput input, .stNumberInput input {{
  background: rgba(208,231,230,.10) !important; border: 1px solid rgba(208,231,230,.32) !important;
  border-radius: 12px !important; color: var(--frost) !important; }}
[data-baseweb="popover"] ul, [data-baseweb="menu"] {{ background: {DEEP} !important; border:1px solid var(--glass-border); }}
[data-baseweb="menu"] li, [data-baseweb="popover"] li {{ color: var(--frost) !important; }}
[data-baseweb="menu"] li:hover {{ background: rgba(149,204,221,.22) !important; }}
label, .stRadio label, .stCheckbox label {{ color: var(--frost) !important; }}
.stSlider [data-testid="stTickBar"] {{ color: var(--ice); }}

/* buttons */
.stButton > button, .stDownloadButton > button, [data-testid="stFormSubmitButton"] > button {{
  background: linear-gradient(135deg, rgba(149,204,221,.42), rgba(66,116,217,.50)); color: #fff;
  border: 1px solid rgba(208,231,230,.55); border-radius: 14px; font-weight: 600;
  box-shadow: inset 0 1px 0 rgba(255,255,255,.4), 0 6px 22px rgba(14,20,70,.35); transition: all .18s ease; }}
.stButton > button:hover, .stDownloadButton > button:hover {{ background: linear-gradient(135deg, rgba(208,231,230,.55), rgba(149,204,221,.55));
  color: {INK}; border-color: var(--frost); transform: translateY(-1px); }}

/* tabs */
.stTabs [data-baseweb="tab-list"] {{ gap: .4rem; border-bottom: none; }}
.stTabs [data-baseweb="tab"] {{ background: rgba(208,231,230,.10); border: 1px solid rgba(208,231,230,.25); border-radius: 999px; padding: .35rem 1rem; color: var(--frost); }}
.stTabs [aria-selected="true"] {{ background: rgba(208,231,230,.28); border-color: var(--frost); }}
.stTabs [data-baseweb="tab-highlight"], .stTabs [data-baseweb="tab-border"] {{ display:none; }}

/* tables & charts */
[data-testid="stDataFrame"], [data-testid="stTable"] {{ border-radius: 16px; overflow: hidden; border: 1px solid var(--glass-border); }}
[data-testid="stPlotlyChart"] {{ border-radius: 18px; }}
iframe {{ border-radius: 20px; }}
a {{ color: var(--ice); }}
hr {{ border-color: rgba(208,231,230,.25); }}
code {{ background: rgba(29,39,102,.6); color: var(--frost); }}
@media (max-width: 720px) {{ .hero h1 {{ font-size: 1.8rem; }} .hero {{ padding: 1.4rem; }} }}
"""


def apply_theme() -> None:
    st.markdown(f"<style>{CSS}</style>", unsafe_allow_html=True)


def hero(title: str, subtitle: str, eyebrow: str = "Celestial Cartographers", pills: list[str] | None = None) -> None:
    pill_html = "".join(f"<span class='pill'>{p}</span>" for p in (pills or []))
    st.markdown(f"<div class='glass hero'><div class='eyebrow'>{eyebrow}</div><h1>{title}</h1><p>{subtitle}</p>"
                f"<div style='margin-top:.9rem'>{pill_html}</div></div>", unsafe_allow_html=True)


def seed_banner() -> None:
    st.markdown("<div class='banner'><b>Seed data.</b> Site values are approximate, hand-compiled demonstration estimates, not pipeline "
                "measurements. Scores are similarity indices, not probabilities. Replace the catalogue with real LOLA/MOLA/SRTM/MODIS "
                "features before drawing scientific conclusions.</div>", unsafe_allow_html=True)


def setup_page(title: str, icon: str = "🛰️") -> None:
    st.set_page_config(page_title=f"{title} · Celestial Cartographers", page_icon=icon, layout="wide")
    apply_theme()
