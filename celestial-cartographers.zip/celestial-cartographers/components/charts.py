"""Plotly charts in the frost theme (blueprint visualization/charts + maps)."""
from __future__ import annotations

from typing import Dict, List, Optional

import numpy as np
import plotly.graph_objects as go

from components.theme import BLUE, DEEP, FROST, ICE, INK
from config.mission_presets import DIMENSION_LABELS, DIMENSIONS

SERIES = [FROST, ICE, "#ffffff", BLUE]
DASHES = ["solid", "dash", "dot", "dashdot"]


def frost(fig: go.Figure, height: int = 420, legend: bool = True) -> go.Figure:
    fig.update_layout(
        height=height, paper_bgcolor="rgba(0,0,0,0)", plot_bgcolor="rgba(208,231,230,.06)",
        font=dict(color=FROST, family="Inter, Segoe UI, sans-serif", size=13),
        margin=dict(l=10, r=10, t=40, b=10), showlegend=legend,
        legend=dict(orientation="h", yanchor="top", y=-0.2, x=0, bgcolor="rgba(29,39,102,.45)", bordercolor="rgba(208,231,230,.3)", borderwidth=1),
        hoverlabel=dict(bgcolor=DEEP, font_color=FROST, bordercolor=ICE),
        colorway=SERIES,
    )
    fig.update_xaxes(automargin=True, gridcolor="rgba(208,231,230,.14)", zerolinecolor="rgba(208,231,230,.25)", linecolor="rgba(208,231,230,.3)")
    fig.update_yaxes(automargin=True, gridcolor="rgba(208,231,230,.14)", zerolinecolor="rgba(208,231,230,.25)", linecolor="rgba(208,231,230,.3)")
    return fig


def _vals(row: dict) -> List[Optional[float]]:
    return [row["dimension_scores"][d] for d in DIMENSIONS]


def radar(rows: List[dict], title: str = "Eight-dimension comparison") -> go.Figure:
    fig = go.Figure()
    cats = [DIMENSION_LABELS[d] for d in DIMENSIONS]
    for i, r in enumerate(rows):
        v = [x if x is not None else 0 for x in _vals(r)]
        miss = [DIMENSION_LABELS[d] for d in DIMENSIONS if r["dimension_scores"][d] is None]
        fig.add_trace(go.Scatterpolar(
            r=v + v[:1], theta=cats + cats[:1], name=r["name"], mode="lines+markers",
            line=dict(color=SERIES[i % len(SERIES)], width=2.4, dash=DASHES[i % len(DASHES)]),
            fill="toself", fillcolor=f"rgba({[208,149,255,66][i%4]},{[231,204,255,116][i%4]},{[230,221,255,217][i%4]},.14)",
            hovertemplate="%{theta}: %{r:.2f}<extra>" + r["name"] + "</extra>",
            customdata=miss))
    fig.update_layout(title=title, polar=dict(bgcolor="rgba(208,231,230,.05)",
                      radialaxis=dict(range=[0, 1], gridcolor="rgba(208,231,230,.25)", tickfont=dict(size=10)),
                      angularaxis=dict(gridcolor="rgba(208,231,230,.25)")))
    fig = frost(fig, 500)
    fig.update_layout(margin=dict(t=70, l=40, r=40), legend=dict(y=-0.1))
    return fig


def hbar(rows: List[dict], title: str = "Dimension scores (horizontal bars)") -> go.Figure:
    fig = go.Figure()
    for i, r in enumerate(rows):
        v = _vals(r)
        fig.add_trace(go.Bar(
            y=[DIMENSION_LABELS[d] for d in DIMENSIONS], x=[x if x is not None else 0 for x in v], orientation="h", name=r["name"],
            marker=dict(color=SERIES[i % len(SERIES)], opacity=.85 if i == 0 else .6, line=dict(color=INK, width=1)),
            text=[f"{x:.2f}" if x is not None else "no data" for x in v], textposition="outside"))
    fig.update_layout(title=title, barmode="group", xaxis=dict(range=[0, 1.15], title="similarity (0-1)"), yaxis=dict(autorange="reversed"))
    fig = frost(fig, 500)
    fig.update_layout(legend=dict(y=-0.3), margin=dict(b=70))
    return fig


def heatmap(rows: List[dict], dims: List[str]) -> go.Figure:
    z = [[r["dimension_scores"][d] for d in dims] for r in rows]
    zt = [[("no data" if v is None else f"{v:.2f}") for v in row] for row in z]
    zz = [[(np.nan if v is None else v) for v in row] for row in z]
    fig = go.Figure(go.Heatmap(z=zz, x=[DIMENSION_LABELS[d] for d in dims], y=[r["name"] for r in rows], zmin=0, zmax=1,
                               colorscale=[[0, INK], [0.5, BLUE], [0.8, ICE], [1, FROST]], text=zt, texttemplate="%{text}",
                               hoverongaps=False, colorbar=dict(title="similarity", tickfont=dict(color=FROST)),
                               hovertemplate="%{y}<br>%{x}: %{text}<extra></extra>"))
    fig.update_layout(title="Candidate x dimension heatmap (blank = no data, not low)", yaxis=dict(autorange="reversed"))
    return frost(fig, 90 + 38 * len(rows), legend=False)


def score_bars(rows: List[dict]) -> go.Figure:
    names = [r["name"] for r in rows]
    fig = go.Figure()
    for key, label, col in (("total", "Similarity index", FROST), ("fidelity", "Analogue fidelity", ICE),
                            ("suitability", "Mission suitability", BLUE), ("transferability", "Transferability (heuristic)", "#ffffff")):
        fig.add_trace(go.Bar(x=names, y=[r[key] if r[key] is not None else 0 for r in rows], name=label, marker_color=col, opacity=.85,
                             marker_line=dict(color=INK, width=1)))
    fig.update_layout(barmode="group", title="Three scores kept separate", yaxis=dict(range=[0, 1]), xaxis=dict(tickangle=-25))
    fig = frost(fig, 470)
    fig.update_layout(legend=dict(y=-0.42), margin=dict(b=90))
    return fig


def candidate_map(cands: List[dict], values: Dict[str, Optional[float]], target: Optional[dict] = None,
                  gibs_url: Optional[str] = None, selected: Optional[List[str]] = None) -> go.Figure:
    lat = [c["lat"] for c in cands]; lon = [c["lon"] for c in cands]
    vals = [values.get(c["id"]) for c in cands]
    size = [10 + 22 * (v if v is not None else 0.1) for v in vals]
    text = [f"<b>{c['name']}</b><br>{c['status']} · {c['scale']}<br>index: " + ("n/a" if v is None else f"{v:.2f}") +
            f"<br>{c['lat']:.2f}, {c['lon']:.2f}" for c, v in zip(cands, vals)]
    fig = go.Figure(go.Scattermap(
        lat=lat, lon=lon, mode="markers+text", text=[c["name"].split(" (")[0][:22] for c in cands], textposition="top right",
        textfont=dict(color=FROST, size=11), hovertext=text, hoverinfo="text",
        marker=dict(size=size, color=[(v if v is not None else 0) for v in vals], colorscale=[[0, BLUE], [.6, ICE], [1, FROST]],
                    cmin=0, cmax=1, opacity=.95, colorbar=dict(title="index", tickfont=dict(color=FROST), len=.6))))
    layers = []
    if gibs_url:
        layers.append(dict(sourcetype="raster", source=[gibs_url], below="traces", opacity=.85))
    fig.update_layout(map=dict(style="carto-darkmatter", center=dict(lat=15, lon=20), zoom=0.8, layers=layers),
                      margin=dict(l=0, r=0, t=0, b=0), height=520, paper_bgcolor="rgba(0,0,0,0)",
                      font=dict(color=FROST), hoverlabel=dict(bgcolor=DEEP, font_color=FROST))
    return fig


def terrain_profiles(profiles: Dict[str, tuple], title: str, normalised: bool = True) -> go.Figure:
    fig = go.Figure()
    for i, (name, (d, z)) in enumerate(profiles.items()):
        fig.add_trace(go.Scatter(x=d / max(d.max(), 1e-9) if normalised else d, y=z, name=name, mode="lines",
                                 line=dict(color=SERIES[i % len(SERIES)], width=3, dash=DASHES[i % len(DASHES)]), fill="tozeroy" if i == 0 else None,
                                 fillcolor="rgba(149,204,221,.12)"))
    fig.update_layout(title=title, xaxis_title="normalised distance" if normalised else "distance (m)",
                      yaxis_title="normalised elevation" if normalised else "elevation (m)")
    return frost(fig, 380)
