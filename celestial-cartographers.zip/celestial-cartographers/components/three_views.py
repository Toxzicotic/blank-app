"""Three.js scenes embedded in Streamlit (blueprint: Three.js custom 3D terrain / planetary scenes).

Self-contained: three.min.js (r149) is inlined from assets/vendor, so scenes render with no CDN
or network access. Procedural textures are used for the Moon/Mars globes (no downloaded imagery).
Terrain scenes take a prepared height grid from Python (blueprint: "prepare tiles or meshes rather
than loading huge raw rasters in the browser").
"""
from __future__ import annotations

import json
from functools import lru_cache
from pathlib import Path
from typing import List, Optional

import streamlit.components.v1 as components

ROOT = Path(__file__).resolve().parents[1]
INK, BLUE, ICE, FROST = "#293681", "#4274D9", "#95CCDD", "#D0E7E6"


@lru_cache(maxsize=1)
def _three() -> str:
    return (ROOT / "assets" / "vendor" / "three.min.js").read_text(encoding="utf-8")


@lru_cache(maxsize=1)
def _land() -> str:
    return (ROOT / "assets" / "land_dots.json").read_text(encoding="utf-8")


def _j(obj) -> str:
    return json.dumps(obj, separators=(",", ":")).replace("</", "<\\/")


_BASE_CSS = f"""
html,body{{margin:0;height:100%;background:transparent;font-family:Inter,Segoe UI,system-ui,sans-serif;color:{FROST};overflow:hidden}}
#wrap{{position:relative;width:100%;height:100%;border-radius:22px;overflow:hidden;
  background:radial-gradient(circle at 28% 18%,rgba(149,204,221,.38),transparent 55%),
             radial-gradient(circle at 85% 80%,rgba(66,116,217,.55),transparent 55%),linear-gradient(160deg,#293681,#1d2766);
  border:1px solid rgba(208,231,230,.38);box-shadow:inset 0 1px 0 rgba(255,255,255,.35)}}
canvas{{display:block;width:100%;height:100%;cursor:grab}} canvas:active{{cursor:grabbing}}
.glass{{position:absolute;padding:.55rem .85rem;border-radius:14px;font-size:12.5px;line-height:1.35;
  background:linear-gradient(135deg,rgba(208,231,230,.22),rgba(149,204,221,.08));border:1px solid rgba(208,231,230,.4);
  backdrop-filter:blur(14px) saturate(150%);-webkit-backdrop-filter:blur(14px) saturate(150%);box-shadow:0 8px 28px rgba(14,20,70,.4)}}
#title{{left:14px;top:14px}} #tip{{pointer-events:none;display:none;z-index:5}} #ctl{{right:14px;bottom:14px;display:flex;gap:.8rem;align-items:center}}
#hint{{left:14px;bottom:14px;color:{ICE};font-size:11.5px}}
input[type=range]{{accent-color:{ICE};width:110px}} label{{font-size:12px;color:{FROST};display:flex;gap:.4rem;align-items:center}}
"""

# ---- tiny orbit controller shared by both scenes (drag = rotate, wheel/pinch = zoom) ----
_ORBIT_JS = """
function Orbit(cam, dom, o){ // o: {r, theta, phi, min, max, auto, target:THREE.Vector3}
  const st = Object.assign({r:3, theta:0.6, phi:1.2, min:1.4, max:8, auto:false, target:new THREE.Vector3()}, o);
  let drag=false, px=0, py=0, pinch=0;
  function apply(){
    st.phi = Math.max(0.12, Math.min(Math.PI-0.12, st.phi));
    cam.position.set(st.target.x + st.r*Math.sin(st.phi)*Math.sin(st.theta), st.target.y + st.r*Math.cos(st.phi), st.target.z + st.r*Math.sin(st.phi)*Math.cos(st.theta));
    cam.lookAt(st.target);
  }
  dom.addEventListener('pointerdown', e=>{drag=true; px=e.clientX; py=e.clientY; st.userTouched=true; dom.setPointerCapture(e.pointerId);});
  dom.addEventListener('pointerup', e=>{drag=false;});
  dom.addEventListener('pointermove', e=>{ if(!drag) return; st.theta -= (e.clientX-px)*0.006; st.phi -= (e.clientY-py)*0.006; px=e.clientX; py=e.clientY; });
  dom.addEventListener('wheel', e=>{ e.preventDefault(); st.r = Math.max(st.min, Math.min(st.max, st.r*(1+Math.sign(e.deltaY)*0.08))); }, {passive:false});
  dom.addEventListener('touchmove', e=>{ if(e.touches.length==2){ const d=Math.hypot(e.touches[0].clientX-e.touches[1].clientX, e.touches[0].clientY-e.touches[1].clientY); if(pinch) st.r=Math.max(st.min,Math.min(st.max, st.r*pinch/d)); pinch=d; } }, {passive:true});
  dom.addEventListener('touchend', ()=>{pinch=0;});
  st.update = function(dt){ if(st.auto && !drag) st.theta += dt*0.12; apply(); };
  apply();
  return st;
}
function lerpColor(a,b,t){ return new THREE.Color(a).lerp(new THREE.Color(b), t); }
"""

_GLOBE_JS = """
const D = __DATA__;
const wrap = document.getElementById('wrap'), canvas = document.getElementById('c'), tip = document.getElementById('tip');
const renderer = new THREE.WebGLRenderer({canvas, antialias:true, alpha:true});
renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
const scene = new THREE.Scene();
const cam = new THREE.PerspectiveCamera(42, 1, 0.1, 100);
function resize(){ const w=wrap.clientWidth, h=wrap.clientHeight; renderer.setSize(w,h,false); cam.aspect=w/h; cam.updateProjectionMatrix(); }
window.addEventListener('resize', resize); resize();
const ctl = Orbit(cam, canvas, {r:3.7, theta:D.lon0*Math.PI/180+Math.PI, phi:Math.PI/2-D.lat0*Math.PI/180, min:1.5, max:7, auto:D.auto});
scene.add(new THREE.AmbientLight(0xD0E7E6, 0.65));
const sun = new THREE.DirectionalLight(0xffffff, 1.0); sun.position.set(5,3,4); scene.add(sun);
const rim = new THREE.DirectionalLight(0x95CCDD, 0.7); rim.position.set(-5,-1,-3); scene.add(rim);
const globe = new THREE.Group(); scene.add(globe);
function ll(lat, lon, r){ const p=(90-lat)*Math.PI/180, t=(lon+180)*Math.PI/180; return new THREE.Vector3(-r*Math.sin(p)*Math.cos(t), r*Math.cos(p), r*Math.sin(p)*Math.sin(t)); }

// ---------- value noise on the sphere ----------
function hash(x,y,z){ let h = x*374761393 + y*668265263 + z*2147483647; h = (h^(h>>13))*1274126177; return ((h^(h>>16))>>>0)/4294967295; }
function vnoise(x,y,z){ const xi=Math.floor(x), yi=Math.floor(y), zi=Math.floor(z); const xf=x-xi, yf=y-yi, zf=z-zi;
  const s=t=>t*t*(3-2*t); const u=s(xf), v=s(yf), w=s(zf); const L=(a,b,t)=>a+(b-a)*t;
  return L(L(L(hash(xi,yi,zi),hash(xi+1,yi,zi),u),L(hash(xi,yi+1,zi),hash(xi+1,yi+1,zi),u),v),
           L(L(hash(xi,yi,zi+1),hash(xi+1,yi,zi+1),u),L(hash(xi,yi+1,zi+1),hash(xi+1,yi+1,zi+1),u),v),w); }
function fbm(x,y,z,o){ let a=1,f=1,s=0,n=0; for(let i=0;i<o;i++){ s+=a*vnoise(x*f,y*f,z*f); n+=a; a*=0.5; f*=2.03; } return s/n; }
function rnd(seed){ let s=seed; return ()=> (s = (s*1664525+1013904223)%4294967296)/4294967296; }

function bodyTexture(kind){
  const W=1024, H=512, c=document.createElement('canvas'); c.width=W; c.height=H; const g=c.getContext('2d'); const img=g.createImageData(W,H);
  for(let y=0;y<H;y++){ const lat=(0.5-y/H)*Math.PI; for(let x=0;x<W;x++){ const lon=(x/W-0.5)*2*Math.PI;
    const X=Math.cos(lat)*Math.cos(lon)*2.2, Y=Math.sin(lat)*2.2, Z=Math.cos(lat)*Math.sin(lon)*2.2;
    const n=fbm(X,Y,Z,5), m=fbm(X*0.6+9,Y*0.6,Z*0.6,3); let r,gc,b;
    if(kind==='Moon'){ const hi=[208,231,230], lo=[78,92,160]; const t=Math.min(1,Math.max(0,(n-0.28)*1.9)); const mare = m>0.55? 0.55:1;
      r=(lo[0]+(hi[0]-lo[0])*t)*mare; gc=(lo[1]+(hi[1]-lo[1])*t)*mare; b=(lo[2]+(hi[2]-lo[2])*t)*(mare*0.4+0.6); }
    else { const hi=[222,170,140], lo=[112,62,70]; const t=Math.min(1,Math.max(0,(n-0.3)*1.8)); r=lo[0]+(hi[0]-lo[0])*t; gc=lo[1]+(hi[1]-lo[1])*t; b=lo[2]+(hi[2]-lo[2])*t;
      const pol=Math.abs(lat)/(Math.PI/2); if(pol>0.93){ r=gc=b=240; } else if(pol>0.9){ r=r*0.5+120; gc=gc*0.5+125; b=b*0.5+125; } }
    const i=(y*W+x)*4; img.data[i]=r; img.data[i+1]=gc; img.data[i+2]=b; img.data[i+3]=255; } }
  g.putImageData(img,0,0);
  const R=rnd(kind==='Moon'?11:5); const nC = kind==='Moon'?260:90;
  for(let k=0;k<nC;k++){ const x=R()*W, y=H*0.1+R()*H*0.8, rad=(kind==='Moon'?3:4)+Math.pow(R(),3)*(kind==='Moon'?34:30);
    const gr=g.createRadialGradient(x,y,rad*0.15,x,y,rad); gr.addColorStop(0,'rgba(20,30,90,0.30)'); gr.addColorStop(0.8,'rgba(20,30,90,0.10)'); gr.addColorStop(0.92,'rgba(255,255,255,0.28)'); gr.addColorStop(1,'rgba(255,255,255,0)');
    g.fillStyle=gr; g.beginPath(); g.ellipse(x,y,rad*1.0,rad*0.9,0,0,6.283); g.fill(); }
  const tex=new THREE.CanvasTexture(c); tex.anisotropy=4; return tex;
}

if(D.body==='Earth'){
  const core = new THREE.Mesh(new THREE.SphereGeometry(1,64,64), new THREE.MeshPhongMaterial({color:0x293681, emissive:0x1d2766, transparent:true, opacity:0.72, shininess:60, specular:0x1d2766}));
  globe.add(core);
  // frosted shell
  globe.add(new THREE.Mesh(new THREE.SphereGeometry(1.012,64,64), new THREE.MeshPhongMaterial({color:0xD0E7E6, transparent:true, opacity:0.10, shininess:220, specular:0x4274D9, side:THREE.FrontSide, depthWrite:false})));
  // land as dots
  const pts=D.land, pos=new Float32Array(pts.length*3); for(let i=0;i<pts.length;i++){ const v=ll(pts[i][0],pts[i][1],1.006); pos.set([v.x,v.y,v.z],i*3); }
  const pg=new THREE.BufferGeometry(); pg.setAttribute('position', new THREE.BufferAttribute(pos,3));
  globe.add(new THREE.Points(pg, new THREE.PointsMaterial({color:0xD0E7E6, size:0.014, sizeAttenuation:true, transparent:true, opacity:0.92})));
  // graticule
  const lines=[]; for(let la=-60; la<=60; la+=30){ for(let lo=-180; lo<180; lo+=4){ lines.push(ll(la,lo,1.004), ll(la,lo+4,1.004)); } }
  for(let lo=-180; lo<180; lo+=30){ for(let la=-88; la<88; la+=4){ lines.push(ll(la,lo,1.004), ll(la+4,lo,1.004)); } }
  globe.add(new THREE.LineSegments(new THREE.BufferGeometry().setFromPoints(lines), new THREE.LineBasicMaterial({color:0x95CCDD, transparent:true, opacity:0.16})));
} else {
  const mat = new THREE.MeshStandardMaterial({map: bodyTexture(D.body), roughness:0.95, metalness:0.0});
  globe.add(new THREE.Mesh(new THREE.SphereGeometry(1,96,96), mat));
  const lines=[]; for(let la=-60; la<=60; la+=30){ for(let lo=-180; lo<180; lo+=4){ lines.push(ll(la,lo,1.003), ll(la,lo+4,1.003)); } }
  for(let lo=-180; lo<180; lo+=30){ for(let la=-88; la<88; la+=4){ lines.push(ll(la,lo,1.003), ll(la+4,lo,1.003)); } }
  globe.add(new THREE.LineSegments(new THREE.BufferGeometry().setFromPoints(lines), new THREE.LineBasicMaterial({color:0xD0E7E6, transparent:true, opacity:0.10})));
}
// atmosphere / frost glow
const glow = new THREE.Mesh(new THREE.SphereGeometry(1.14,48,48), new THREE.ShaderMaterial({transparent:true, side:THREE.BackSide, blending:THREE.AdditiveBlending, depthWrite:false,
  uniforms:{c:{value:new THREE.Color(D.body==='Mars'?0xDEAA8C:0x95CCDD)}},
  vertexShader:'varying vec3 n; void main(){ n=normalize(normalMatrix*normal); gl_Position=projectionMatrix*modelViewMatrix*vec4(position,1.0);} ',
  fragmentShader:'varying vec3 n; uniform vec3 c; void main(){ float i=pow(max(0.0,1.0+dot(n,vec3(0,0,1.0))),4.5); gl_FragColor=vec4(c,1.0)*i*0.55; }'}));
scene.add(glow);
// stars
const sp=new Float32Array(900*3); const R=rnd(3); for(let i=0;i<900;i++){ const v=new THREE.Vector3(R()-.5,R()-.5,R()-.5).normalize().multiplyScalar(30+R()*20); sp.set([v.x,v.y,v.z],i*3); }
const sg=new THREE.BufferGeometry(); sg.setAttribute('position', new THREE.BufferAttribute(sp,3)); scene.add(new THREE.Points(sg,new THREE.PointsMaterial({color:0xD0E7E6,size:0.09,transparent:true,opacity:.7})));

// markers (colour/size encode value; unknown = hollow ring)
const markers=[], rings=[];
D.markers.forEach(m=>{
  const v = m.value; const known = v!==null && v!==undefined;
  const col = known ? (v<0.5 ? lerpColor('#95CCDD','#D0E7E6',v*2) : new THREE.Color('#ffffff')) : new THREE.Color('#4274D9');
  const size = known ? 0.018+0.03*v : 0.02;
  const mesh=new THREE.Mesh(new THREE.SphereGeometry(size,16,16), new THREE.MeshBasicMaterial({color:col})); mesh.position.copy(ll(m.lat,m.lon,1.02)); mesh.userData=m; globe.add(mesh); markers.push(mesh);
  const ring=new THREE.Mesh(new THREE.RingGeometry(size*1.6,size*2.0,32), new THREE.MeshBasicMaterial({color:m.selected?0xffffff:0x95CCDD, transparent:true, opacity:m.selected?0.95:0.5, side:THREE.DoubleSide}));
  ring.position.copy(ll(m.lat,m.lon,1.021)); ring.lookAt(ring.position.clone().multiplyScalar(2)); ring.userData.base=size; globe.add(ring); rings.push(ring);
  if(m.isTarget){ const sq=new THREE.Mesh(new THREE.OctahedronGeometry(size*1.6), new THREE.MeshBasicMaterial({color:0xffffff, wireframe:true})); sq.position.copy(ll(m.lat,m.lon,1.05)); globe.add(sq); rings.push(sq); }
});
// hover
const ray=new THREE.Raycaster(); ray.params.Points={threshold:0.02}; const mouse=new THREE.Vector2(-9,-9);
canvas.addEventListener('pointermove', e=>{ const r=canvas.getBoundingClientRect(); mouse.set(((e.clientX-r.left)/r.width)*2-1, -((e.clientY-r.top)/r.height)*2+1); tip.style.left=(e.clientX-r.left+14)+'px'; tip.style.top=(e.clientY-r.top+14)+'px'; });
canvas.addEventListener('pointerleave', ()=>{ mouse.set(-9,-9); tip.style.display='none'; });
function hover(){ ray.setFromCamera(mouse,cam); const hits=ray.intersectObjects(markers,false);
  if(hits.length){ const d=hits[0].object.userData; tip.innerHTML='<b>'+d.name+'</b><br>'+d.line; tip.style.display='block'; } else tip.style.display='none'; }
document.getElementById('hint').textContent='drag to rotate · scroll to zoom · hover a marker';
let last=performance.now();
(function loop(t){ requestAnimationFrame(loop); const dt=Math.min(0.05,(t-last)/1000); last=t; ctl.update(dt);
  rings.forEach((r,i)=>{ const s=1+0.15*Math.sin(t/500+i); r.scale.set(s,s,s); }); hover(); renderer.render(scene,cam); })(last);
"""

_TERRAIN_JS = """
const D = __DATA__;
const wrap=document.getElementById('wrap'), canvas=document.getElementById('c');
const renderer=new THREE.WebGLRenderer({canvas, antialias:true, alpha:true}); renderer.setPixelRatio(Math.min(window.devicePixelRatio,2));
const scene=new THREE.Scene(); const cam=new THREE.PerspectiveCamera(40,1,0.01,100);
function resize(){ const w=wrap.clientWidth,h=wrap.clientHeight; renderer.setSize(w,h,false); cam.aspect=w/h; cam.updateProjectionMatrix(); }
window.addEventListener('resize',resize); resize();
const ctl=Orbit(cam,canvas,{r:1.9, theta:0.7, phi:1.05, min:0.6, max:5, auto:true, target:new THREE.Vector3(0,0.08,0)});
scene.add(new THREE.AmbientLight(0xD0E7E6,0.55)); const sun=new THREE.DirectionalLight(0xffffff,1.15); sun.position.set(2,3,1.5); scene.add(sun);
const fill=new THREE.DirectionalLight(0x4274D9,0.6); fill.position.set(-3,1,-2); scene.add(fill);
const n=D.n; let hmin=1e9,hmax=-1e9; D.h.forEach(v=>{ if(v<hmin)hmin=v; if(v>hmax)hmax=v; }); const span=(hmax-hmin)||1;
const geo=new THREE.PlaneGeometry(1,1,n-1,n-1); geo.rotateX(-Math.PI/2);
const pos=geo.attributes.position; const col=new Float32Array(pos.count*3);
const ramp=['#1d2766','#293681','#4274D9','#95CCDD','#D0E7E6'].map(c=>new THREE.Color(c));
function rampAt(t){ const x=Math.min(0.9999,Math.max(0,t))*(ramp.length-1), i=Math.floor(x); return ramp[i].clone().lerp(ramp[i+1],x-i); }
let exag=D.exag;
function build(){ for(let i=0;i<pos.count;i++){ const t=(D.h[i]-hmin)/span; pos.setY(i, t*0.22*exag); const c=rampAt(t); col.set([c.r,c.g,c.b],i*3); }
  geo.setAttribute('color', new THREE.BufferAttribute(col,3)); pos.needsUpdate=true; geo.computeVertexNormals(); }
build();
const mesh=new THREE.Mesh(geo,new THREE.MeshStandardMaterial({vertexColors:true, roughness:0.82, metalness:0.05, flatShading:false})); scene.add(mesh);
const wire=new THREE.Mesh(geo,new THREE.MeshBasicMaterial({color:0xD0E7E6, wireframe:true, transparent:true, opacity:0.14})); wire.visible=false; scene.add(wire);
// base plate / frosted slab
const slab=new THREE.Mesh(new THREE.BoxGeometry(1.04,0.03,1.04), new THREE.MeshPhongMaterial({color:0xD0E7E6, transparent:true, opacity:0.22, shininess:120})); slab.position.y=-0.02; scene.add(slab);
const grid=new THREE.GridHelper(1.04,10,0x95CCDD,0x95CCDD); grid.material.transparent=true; grid.material.opacity=0.18; grid.position.y=-0.0049; scene.add(grid);
function cellToXYZ(r,c){ const i=Math.round(r)*n+Math.round(c); return new THREE.Vector3((c/(n-1)-0.5), pos.getY(i)+0.012, (r/(n-1)-0.5)); }
let pathObj=null, marks=[];
function drawPath(){ if(pathObj){ scene.remove(pathObj); } marks.forEach(m=>scene.remove(m)); marks=[];
  if(!D.path||D.path.length<2) return; const pts=D.path.map(p=>cellToXYZ(p[0],p[1]));
  pathObj=new THREE.Mesh(new THREE.TubeGeometry(new THREE.CatmullRomCurve3(pts),Math.min(400,pts.length*3),0.004,6,false), new THREE.MeshBasicMaterial({color:0xffffff})); scene.add(pathObj);
  [[D.path[0],0x95CCDD],[D.path[D.path.length-1],0xffffff]].forEach(([p,c])=>{ const m=new THREE.Mesh(new THREE.SphereGeometry(0.014,16,16),new THREE.MeshBasicMaterial({color:c})); m.position.copy(cellToXYZ(p[0],p[1])); scene.add(m); marks.push(m); });
  if(D.lander){ const m=new THREE.Mesh(new THREE.ConeGeometry(0.014,0.04,6),new THREE.MeshBasicMaterial({color:0x4274D9})); const q=cellToXYZ(D.lander[0],D.lander[1]); q.y+=0.02; m.position.copy(q); scene.add(m); marks.push(m); } }
drawPath();
const sx=document.getElementById('exag'), sw=document.getElementById('wf'), sa=document.getElementById('ar');
sx.value=exag; sx.oninput=()=>{ exag=parseFloat(sx.value); build(); drawPath(); }; sw.onchange=()=>{ wire.visible=sw.checked; }; sa.checked=true; sa.onchange=()=>{ ctl.auto=sa.checked; };
document.getElementById('hint').textContent='drag to orbit · scroll to zoom';
document.getElementById('info').innerHTML=D.info;
let last=performance.now(); (function loop(t){ requestAnimationFrame(loop); const dt=Math.min(0.05,(t-last)/1000); last=t; ctl.update(dt); renderer.render(scene,cam); })(last);
"""


def _page(js: str, data: dict, extra_ui: str = "", title_html: str = "") -> str:
    return (f"<!doctype html><html><head><meta charset='utf-8'><meta name='viewport' content='width=device-width,initial-scale=1'>"
            f"<style>{_BASE_CSS}</style></head><body><div id='wrap'><canvas id='c'></canvas>"
            f"{title_html}<div id='tip' class='glass'></div><div id='hint' class='glass' style='padding:.3rem .7rem'></div>{extra_ui}</div>"
            f"<script>{_three()}</script><script>{_ORBIT_JS}</script><script>{js.replace('__DATA__', _j(data))}</script></body></html>")


def globe_html(body: str, markers: List[dict], focus: Optional[tuple] = None, auto_rotate: bool = True, title: str = "") -> str:
    lat0, lon0 = focus if focus else (15, 20)
    data = {"body": body, "markers": markers, "lat0": lat0, "lon0": lon0, "auto": auto_rotate,
            "land": json.loads(_land()) if body == "Earth" else []}
    t = f"<div id='title' class='glass'><b>{title or body}</b><br><span style='color:{ICE}'>3D globe · {len(markers)} markers</span></div>"
    return _page(_GLOBE_JS, data, title_html=t)


def terrain_html(heights, info: str = "", path=None, lander=None, exag: float = 1.6) -> str:
    import numpy as np
    h = np.asarray(heights, dtype=float)
    data = {"n": int(h.shape[0]), "h": [round(float(v), 3) for v in h.ravel()], "exag": exag,
            "path": [list(map(int, p)) for p in (path or [])], "lander": list(map(int, lander)) if lander else None, "info": info}
    ui = ("<div id='info' class='glass' style='left:14px;top:14px'></div>"
          "<div id='ctl' class='glass'><label>vertical ×<input id='exag' type='range' min='0.3' max='4' step='0.1'></label>"
          "<label><input id='wf' type='checkbox'>wireframe</label><label><input id='ar' type='checkbox'>rotate</label></div>")
    return _page(_TERRAIN_JS, data, extra_ui=ui)


def show(html: str, height: int = 540) -> None:
    """Embed a generated scene. Uses st.iframe on current Streamlit; falls back to components.html on older versions.
    The HTML is built only from this app's own data (never from user-supplied markup)."""
    import streamlit as st
    if hasattr(st, "iframe"):
        st.iframe(html, height=height)
    else:  # pragma: no cover
        components.html(html, height=height, scrolling=False)
