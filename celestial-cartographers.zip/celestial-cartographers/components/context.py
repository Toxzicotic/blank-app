"""Shared sidebar + analysis context used by every page (target, objective, editable weights)."""
from __future__ import annotations

import streamlit as st

from config.mission_presets import DIMENSION_LABELS, DIMENSIONS, PRESETS
from components.theme import apply_theme
from data_sources import live_earth
from data_sources.seed_catalog import CANDIDATES, get_target, get_targets
from scientific_engine.similarity import normalise_weights, rank_candidates


def _apply_preset() -> None:
    for d in DIMENSIONS:
        st.session_state[f"w_{d}"] = int(round(PRESETS[st.session_state["objective"]][d] * 100))


def _reset_target() -> None:
    st.session_state["target_id"] = get_targets(st.session_state["body"])[0]["id"]


def _persist(keys) -> None:
    # Widgets that are not rendered on the current page lose state; re-assigning keeps it across pages.
    for k in keys:
        if k in st.session_state:
            st.session_state[k] = st.session_state[k]


def init_state() -> None:
    st.session_state.setdefault("body", "Moon")
    st.session_state.setdefault("objective", "Polar Ice Drilling")
    st.session_state.setdefault("target_id", get_targets(st.session_state["body"])[0]["id"])
    if "w_geology" not in st.session_state:
        _apply_preset()
    _persist(["body", "objective", "target_id"] + [f"w_{d}" for d in DIMENSIONS])


def current_weights() -> dict:
    return {d: st.session_state[f"w_{d}"] / 100.0 for d in DIMENSIONS}


def sidebar() -> dict:
    """Render the global selectors and return the analysis context."""
    apply_theme()  # every page themes itself, so direct URLs and reruns are never unstyled
    init_state()
    with st.sidebar:
        st.markdown("### 🛰️ Mission setup")
        st.radio("Target world", ["Moon", "Mars"], key="body", horizontal=True, on_change=_reset_target)
        opts = get_targets(st.session_state["body"])
        ids = [t["id"] for t in opts]
        st.selectbox("Target region", ids, key="target_id", format_func=lambda i: next(t["name"] for t in opts if t["id"] == i))
        st.selectbox("Mission objective", list(PRESETS), key="objective", on_change=_apply_preset)
        w = normalise_weights(current_weights())
        st.caption("Active weights: " + " · ".join(f"{DIMENSION_LABELS[d][:4]} {v:.0%}" for d, v in w.items() if v > 0))
        st.markdown("<div class='tiny'>Edit weights on the Mission Control page. Presets are placeholders, not validated.</div>", unsafe_allow_html=True)
    target = get_target(st.session_state["target_id"])
    objective = st.session_state["objective"]
    weights = current_weights()
    rows = rank_candidates(target, CANDIDATES, weights, objective)
    return {"target": target, "objective": objective, "weights": weights, "rows": rows,
            "cands": {c["id"]: c for c in CANDIDATES}, "cand_list": CANDIDATES}


# ---- cached live feeds (TTL keeps the app from hammering free APIs) ----
@st.cache_data(ttl=600, show_spinner=False)
def live_current(lat: float, lon: float) -> dict:
    return live_earth.open_meteo_current(lat, lon)


@st.cache_data(ttl=6 * 3600, show_spinner=False)
def live_monthly(lat: float, lon: float) -> dict:
    return live_earth.open_meteo_monthly(lat, lon)


@st.cache_data(ttl=300, show_spinner=False)
def live_quakes(lat: float, lon: float, radius_km: float) -> dict:
    return live_earth.usgs_quakes_near(lat, lon, radius_km)
