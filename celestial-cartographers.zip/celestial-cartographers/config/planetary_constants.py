"""Representative planetary reference values (blueprint Workspace 04 / Appendix A12).

Values are representative; local and temporal variation applies (especially Mars pressure
and radiation). Verify against authoritative sources before any quantitative use.
"""

PLANETS = {
    "Earth": {
        "gravity": 9.81,            # m/s^2
        "pressure_kpa": 101.3,      # sea level
        "atmosphere": "Nitrogen/oxygen dominated",
        "radiation_msv_day": 0.007, # ~2.4 mSv/yr natural background, shielded by atmosphere + magnetosphere
        "temp_mean_c": 15.0,
        "temp_min_c": -60.0,
        "temp_max_c": 50.0,
    },
    "Moon": {
        "gravity": 1.62,
        "pressure_kpa": 3e-13,      # ~3e-10 Pa: near vacuum
        "atmosphere": "No substantial atmosphere",
        "radiation_msv_day": 1.0,   # order of 0.3-1.4 mSv/day measured on surface, varies with solar cycle
        "temp_mean_c": -20.0,
        "temp_min_c": -240.0,       # permanently shadowed regions
        "temp_max_c": 120.0,
    },
    "Mars": {
        "gravity": 3.71,
        "pressure_kpa": 0.6,        # variable with season/elevation
        "atmosphere": "Thin, CO2-dominated",
        "radiation_msv_day": 0.67,  # order of MSL RAD surface dose
        "temp_mean_c": -63.0,
        "temp_min_c": -140.0,
        "temp_max_c": 20.0,
    },
}

# Physical conditions an Earth site cannot reproduce. Used by the scorecard and transferability.
# status: "partial" = can be partially emulated with equipment, "no" = cannot be reproduced at an Earth site
PHYSICAL_FACTORS = [
    # key, label, unit, how_it_is_handled
    ("gravity", "Surface gravity", "m/s²", "no"),
    ("pressure_kpa", "Atmospheric pressure", "kPa", "no"),
    ("radiation_msv_day", "Surface radiation dose", "mSv/day", "no"),
    ("temperature", "Temperature range", "°C", "partial"),
    ("atmosphere", "Atmospheric composition", "-", "no"),
    ("surface_chemistry", "Surface chemistry (perchlorates, oxidants, regolith)", "-", "partial"),
]

# Mismatch magnitude in [0, 1] used only by the heuristic transferability score.
def mismatch(body: str, factor: str) -> float:
    e, b = PLANETS["Earth"], PLANETS[body]
    if factor == "gravity":
        return min(1.0, abs(e["gravity"] - b["gravity"]) / e["gravity"])
    if factor == "pressure_kpa":
        return min(1.0, abs(e["pressure_kpa"] - b["pressure_kpa"]) / e["pressure_kpa"])
    if factor == "radiation_msv_day":
        return 1.0 if b["radiation_msv_day"] > 20 * e["radiation_msv_day"] else 0.5
    return 0.0
